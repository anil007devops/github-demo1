<?php
include 'connection.php';

if($_POST['action'] == "delete") // add new event
{
  mysqli_query($connection,"DELETE from event where id = '".mysqli_real_escape_string($connection,$_POST["id"])."'");
     if (mysqli_affected_rows($connection) > 0) {
         echo "1";
     }
     exit;
}
?>
