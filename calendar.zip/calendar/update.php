<?php
include 'connection.php';

if($_POST['action'] == "update") // update event while drop event from one date to another date
{
  mysqli_query($connection,"UPDATE event set
            start = '".mysqli_real_escape_string($connection,date('Y-m-d H:i:s',strtotime($_POST["start"])))."',
            end = '".mysqli_real_escape_string($connection,date('Y-m-d H:i:s',strtotime($_POST["end"])))."'
            where id = '".mysqli_real_escape_string($connection,$_POST["id"])."'");
       echo $_POST["id"];
        exit;
}
?>
