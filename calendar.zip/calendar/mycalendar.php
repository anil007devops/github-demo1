
<!DOCTYPE html>
<html>
<head>
<meta charset='utf-8' />
<link href='css/fullcalendar.min.css' rel='stylesheet' />
<link href='css/fullcalendar.print.min.css' rel='stylesheet' media='print' />
<link href='css/bootstrap.css' rel='stylesheet'/>

<style>

	body {
		margin: 40px 10px;
		padding: 0;
		font-family: "Lucida Grande",Helvetica,Arial,Verdana,sans-serif;
		font-size: 14px;
	}

	#calendar {
		max-width: 900px;
		margin: 0 auto;
	}

</style>
</head>
<body>

<div class="container">
<div id="calendar"></div>
<!-- Modal  to Add Event -->
<div id="createEventModal" class="modal fade" role="dialog">
 <div class="modal-dialog">

 <!-- Modal content-->
 <div class="modal-content">
 <div class="modal-header">
 <button type="button" class="close" data-dismiss="modal">&times;</button>
 <h4 class="modal-title">Add Event</h4>
 </div>
 <div class="modal-body">
 <div class="control-group">
 <label class="control-label" for="inputPatient">Event:</label>
 <div class="field desc">
 <textarea class="form-control" id="title" name="title" placeholder="Event" value=""></textarea>
 </div>
 </div>

 <input type="hidden" id="startTime"/>
 <input type="hidden" id="endTime"/>



 <div class="control-group">
 <label class="control-label" for="when">When:</label>
 <div class="controls controls-row" id="when" style="margin-top:5px;">
 </div>
 </div>

 </div>
 <div class="modal-footer">
 <button class="btn" data-dismiss="modal" aria-hidden="true">Cancel</button>
 <button type="submit" class="btn btn-primary" id="submitButton">Save</button>
 </div>
 </div>

 </div>
</div>

<!-- Modal to Event Details -->
<div id="calendarModal" class="modal fade">
<div class="modal-dialog">
 <div class="modal-content">
 <div class="modal-header">
 <button type="button" class="close" data-dismiss="modal">&times;</button>
 <h4 class="modal-title">Event Details</h4>
 </div>
 <div id="modalBody" class="modal-body">
 <h4 id="modalTitle" class="modal-title"></h4>
 <div id="modalWhen" style="margin-top:5px;"></div>
 </div>
 <input type="hidden" id="eventID"/>
 <div class="modal-footer">
 <button class="btn" data-dismiss="modal" aria-hidden="true">Cancel</button>
 <button type="submit" class="btn btn-danger" id="deleteButton">Delete</button>
 </div>
 </div>
</div>
</div>
<!--Modal-->

</div><!--end of container -->
<script src='js/moment.min.js'></script>
<!-- <script src='js/jquery.min.js'></script> -->
<script src='js/jquery.js'></script>
<script src='js/fullcalendar.min.js'></script>
<script src='js/bootstrap.min.js'></script>
<script src="js/myscript.js"></script>
</body>
</html>
