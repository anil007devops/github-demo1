<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "calendar";

 $connection = mysqli_connect($servername, $username, $password, $dbname) or die(mysqli_error($connection));

 ?>
