<?php
include 'admin-header.html';
//include 'usersession.php';
?>
<!--
<div class="container">
  <div class="row">
  <div class="col-xs-12 col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-3">

<form role="form" ng-submit="addCategory()">
    <h4 id="rcorners6">Category details :</h4>
     <hr class="colorgraph">

<div class="form-group">
    <label for="category_name">Copier performance category</label>
    <input type="text" name="category_name" ng-model="copier.category_name" id="category_name" class="form-control input-lg" placeholder="Category name" tabindex="1">
</div>

<div class="row">
    <div class="col-xs-12 col-md-12"><input type="submit" value="Submit" style="background: #00578d;" class="btn btn-primary btn-block btn-lg" tabindex="11"></div>
    <input type="hidden" name="_token" value="{{ csrf_token() }}">
</div>
</form>

</div>
</div>
</div> -->
