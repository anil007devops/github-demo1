<?php include 'admin-header.html';?>

<style>
#rcorners6 {
    border-radius: 15px 50px;
    background: #00578d;
    padding: 20px;
    color:#fff;

}

.input-lg {
    height: 46px;
    padding: 10px 16px;
    font-size: 13px;
    line-height: 1.3333333;
    border-radius: 6px;
}
/* Overriding styles */

::-webkit-input-placeholder {
   font-size: 15px!important;

}

:-moz-placeholder { /* Firefox 18- */
      font-size: 15px!important;
}
::-moz-placeholder {  /* Firefox 19+ */
      font-size: 15px!important;
}

</style>

<div class="container-fluid">
  <!--table view -->
<div class="row">
<br>
<div class="col-sm-3" style="border-right:px solid #000;">

  <div class="well">
      <button style="margin-bottom:20px;background:#337ab7;" type="button" class="btn btn-info btn-lg btn-block">Manage copier details</button>
  <ul class="list-group">
    <li class="list-group-item"><a href="#/add-categories">Categories</a></li>
    <li class="list-group-item"><a href="#/add-copiers">Copiers</a></li>
    <li class="list-group-item"><a href="#/add-accessories">Accessories</a></li>
    <li class="list-group-item"><a href="#/add-payments">Plan details</a></li>
    <li class="list-group-item"><a href="#/add-crystalball-service">Copier service details</a></li>
 <li class="list-group-item"><a href="#/add-pricing-policy">CrystalBall fair pricing policy</a></li>
  </ul>
</div>
</div>
<div class="col-sm-9">
<div class="table-responsive">
<table class="table table-striped" style="border:1px solid #999;">
  <h3 style="margin-top:1px;"class="pull-left">Copiers</h3>
  <button style="margin-bottom:20px;background:#337ab7;" type="button" class="btn btn-info btn-lg pull-right" data-toggle="modal" data-target="#myModal">Add copier</button>
<thead>
<tr style="background:#337ab7;color:#fff;">
<th>Copier name/model</th>
<th>Category</th>
<th>Monthly pages</th>
<th>Print page per minute</th>
<th>Cents per color page</th>
<th>Cents per Black & white page</th>
<th>Copier monthly price</th>
<th>Accessible by</th>
<th>Action</th>
</tr>
</thead>
<tbody ng-repeat="copier in copiers">
<tr>

<td>{{ copier.copier_model}}</td>
<td>{{copier.category_name}}</td>
<td>{{copier.monthly_pages}}</td>

<td>{{copier.print_page_per_minute}}</td>

<td>{{copier.price_color_page}} cents</td>

<td>{{copier.price_bw_page}} cents</td>

<td>${{copier.monthly_price}}</td>

<td>{{copier.used_by}}</td>

<td>
    <a data-toggle="tooltip" title="Edit"><span ng-click="toggle(copier)" class="glyphicon glyphicon-pencil"></span></a> &nbsp;
    <a data-toggle="tooltip" title="Delete"><span ng-click="disableCopiers(copier.id)" class="glyphicon glyphicon-trash"></span></a>
 </td>
</tr>
</tbody>
</table>
</div>
</div>
<!-- <div class="col-sm-3"></div>
<div class="col-sm-9" ng-repeat="category in categories">
<div ng-if="category.id==copid">
<div class="table-responsive">
<h4 style="line-height:30px;color:#337ab7;">Copier belongs to following category :</h4>
<table class="table table-bordered"><tr class="info"><th>Category Name</th></tr>
<tr><td><span class="glyphicon glyphicon-stop"></span> {{category.category_name}}</td></tr></table>
</div>
</div>
</div> -->
</div>
<!-- end table view-->

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">
    <!-- Modal content-->
   <div class="modal-content">
     <div class="modal-header">
       <button type="button" class="close" data-dismiss="modal">&times;</button>
       <h4 class="modal-title">Fill the copier details according to performance categories</h4>
     </div>
     <div class="modal-body">
    <div class="row">
        <div class="col-xs-12 col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-3">
            <form role="form">
                <h4 id="rcorners6">Copiers details :</h4>
                <hr class="colorgraph">
  <!-- <input type="text" ng-model="copier.id"></input>  for testing -->
  <div class="form-group">
      <label for="copier_model">Copier name/model</label>
      <input type="text" name="copier_model" ng-model="copier.copier_model" id="copier_model" class="form-control input-lg" placeholder="Copier name/model" tabindex="2">
    </div>

                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-6">
                          <div class="form-group">
                              <label for="category_name">Select performance category</label>
                              <select  class="form-control input-lg" id="category_name" ng-model="copier.id">
                              <option value="">Select category</option>
                              <option value='{{category.id}}' ng-repeat="category in categories">{{category.category_name}}</option>
                              </select>
                          </div>
                        </div>

                    <div class="col-xs-12 col-sm-6 col-md-6">
                      <div class="form-group">
                          <label for="monthly_pages">Monthly pages</label>
                          <input type="text" name="monthly_pages" ng-model="copier.monthly_pages" id="monthly_pages" class="form-control input-lg" placeholder="Monthly pages" tabindex="3">
                      </div>

                    </div>
                </div>


                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-6">
                      <div class="form-group">
                          <label for="print_page_per_minute">Printing page per minute</label>
                          <input type="text" name="print_page_per_minute" ng-model="copier.print_page_per_minute" id="print_page_per_minute" class="form-control input-lg" placeholder="Printing page per minute" tabindex="4">
                      </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-6">
                      <div class="form-group">
                          <label for="price_color_page">Price per color page</label>
                          <input type="text" name="price_color_page" ng-model="copier.price_color_page" id="price_color_page" class="form-control input-lg" placeholder="Price per color page" tabindex="5">
                      </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-6">
                      <div class="form-group">
                          <label for="price_bw_page">Price per black & white page</label>
                          <input type="text" name="price_bw_page" ng-model="copier.price_bw_page" id="price_bw_page" class="form-control input-lg" placeholder="Price per black & white page" tabindex="6">
                      </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-6">
                      <div class="form-group">
                          <label for="monthly_price">Copier monthly price</label>
                          <input type="text" name="monthly_price" ng-model="copier.monthly_price" id="monthly_price" class="form-control input-lg" placeholder="Copier monthly price" tabindex="6">
                      </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="used_by">Accessible by</label>
                    <select  class="form-control input-lg" id="plan" ng-model="copier.used_by">
                    <option value="">Select max users</option>
                    <option value="1-4 users">1-4 users</option>
                    <option value="2-7 users">2-7 users</option>
                    <option value="For less than 9 users">For less than 9 users</option>
                    <option value="Larger workgroup">Larger workgroup</option>
                    <option value="Many users,Busy office,High productivity">Many users,Busy office,High productivity</option>
                    </select>
                </div>

                <div class="row">
                    <div class="col-xs-12 col-md-12">
                <button type="submit" data-dismiss="modal" ng-click="addcopier()" style="background: #00578d;" class="btn btn-primary btn-block btn-lg" tabindex="11">Submit</button>
                </div>
                    <input type="hidden" name="_token" value="{{ csrf_token() }}">
                </div>
            </form>
            <br><br>
        </div>
    </div>
 </div><!--modal body closed-->
 <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

</div>
</div><!--end of the model -->

<!--model2 for editing
<!-- Modal -->
<div id="myModal2" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">
    <!-- Modal content-->
   <div class="modal-content">
     <div class="modal-header">
       <button type="button" class="close" data-dismiss="modal">&times;</button>
       <h4 class="modal-title">Updating the copier details according to performance categories</h4>
     </div>
     <div class="modal-body">
    <div class="row">
        <div class="col-xs-12 col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-3">
            <form role="form">
                <h4 id="rcorners6">Copiers details :</h4>
                <hr class="colorgraph">
  <!-- <input type="text" ng-model="copier.id"></input>  for testing -->
  <div class="form-group">
      <label for="copier_model">Copier name/model</label>
      <input type="text" ng-model="editcopiers.copier_model" id="copier_model" class="form-control input-lg" placeholder="Copier name/model" tabindex="2">
    </div>

                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-6">
                          <div class="form-group" ng-repeat="category in categories">
                            <div ng-if="editcopiers.category_id==category.id">
                              <label for="category_name">Category</label>
                              <input type="text" class="form-control input-lg" ng-model="category.category_name" disabled>

                              <!-- <select class="form-control input-lg" id="category_name" ng-model="editcopiers.idd" ng-required>
                              <option value="" disabled>Select category</option>
                              <option value='{{category.id}}'>{{category.category_name}}</option>
                              </select> -->
                          </div>
                        </div>
                        </div>

                    <div class="col-xs-12 col-sm-6 col-md-6">
                      <div class="form-group">
                          <label for="monthly_pages">Monthly pages</label>
                          <input type="text" ng-model="editcopiers.monthly_pages" class="form-control input-lg" placeholder="Monthly pages" tabindex="3">
                      </div>

                    </div>
                </div>


                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-6">
                      <div class="form-group">
                          <label for="print_page_per_minute">Printing page per minute</label>
                          <input type="text" ng-model="editcopiers.print_page_per_minute" class="form-control input-lg" placeholder="Printing page per minute" tabindex="4">
                      </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-6">
                      <div class="form-group">
                          <label for="price_color_page">Price per color page</label>
                          <input type="text" name="price_color_page" ng-model="editcopiers.price_color_page" class="form-control input-lg" placeholder="Price per color page" tabindex="5">
                      </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-6">
                      <div class="form-group">
                          <label for="price_bw_page">Price per black & white page</label>
                          <input type="text" ng-model="editcopiers.price_bw_page" class="form-control input-lg" placeholder="Price per black & white page" tabindex="6">
                      </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-6">
                      <div class="form-group">
                          <label for="monthly_price">Copier monthly price</label>
                          <input type="text" ng-model="editcopiers.monthly_price" class="form-control input-lg" placeholder="Copier monthly price" tabindex="6">
                      </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="used_by">Accessible by</label>
                    <select  class="form-control input-lg" id="plan" ng-model="editcopiers.used_by">
                    <option value="">Select max users</option>
                    <option value="1-4 users">1-4 users</option>
                    <option value="2-7 users">2-7 users</option>
                    <option value="For less than 9 users">For less than 9 users</option>
                    <option value="Larger workgroup">Larger workgroup</option>
                    <option value="Many users,Busy office,High productivity">Many users,Busy office,High productivity</option>
                    </select>
                </div>

                <div class="row">
                    <div class="col-xs-12 col-md-12">
                <button type="submit" data-dismiss="modal" ng-click="editCopiers(editcopiers,editcopiers.id)" style="background: #00578d;" class="btn btn-primary btn-block btn-lg" tabindex="11">Submit</button>
                </div>
                    <input type="hidden" name="_token" value="{{ csrf_token() }}">
                </div>
            </form>
            <br><br>
        </div>
    </div>
 </div><!--modal body closed-->
 <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

</div>
</div><!--end of the model -->
</div><!-- closed main container -->
