<?php include 'user-header.html'; ?>
  <style>
  body {
      position: relative;
      top:50px;
  }

  #section1 {color: #; background-color: #1E88E5;margin:0px;}

  @media screen and (max-width: 810px) {
    #section1, #section2, #section3, #section41, #section42  {
        margin-left: 10px;

    }
  }
  .sidebar-nav-fixed {
	width:30%;


}

@media (max-width: 767px) {
     .sidebar-nav-fixed {
         width:auto;
     }
 }

 @media (max-width: 979px) {
     .sidebar-nav-fixed {
         position:static;
        width: auto;
     }
 }
  </style>

</head>
<body>
<div class="container-fluid">
<br><br><br><br>
  <div class="row" style="padding:20px;">

    <nav class="col-xs-12 col-sm-6 col-sm-5 text-center">
 <div class="sidebar-nav-fixed affix">
      <img src="images/copier44.jpg" class="img-responsive" style="margin-left:0px;margin-top:50px;"/>
  <a href=""><h4 class="text-center"><span class="glyphicon glyphicon-picture"></span> VIEW GALLERY</h4></a>
  <br><h4 class="text-center">Built-in Features</h4><br>
  <ul class="list-inline text-center">
    <li><h4><span class=" glyphicon glyphicon-th-large"></span><br> Color</h4></li>
    <li><h4><span class=" glyphicon glyphicon-cd"></span><br> Scan</h4></li>
    <li><h4><span class=" glyphicon glyphicon-copy"></span><br> Copy</h4></li>
    <li><h4><span class=" glyphicon glyphicon-envelope"></span><br> Email</h4></li>
    <li><h4><span class=" glyphicon glyphicon-print"></span><br> Print</h4></li>
  </ul>
</div>
    </nav>
    <div class="col-xs-12 col-sm-6 col-sm-5 col-5">
      <div id="section1" ng-repeat="copier in copiers">

        <div class="panel panel-default well">
            <div class="panel-body">

                <!-- <h3 style="" class="pull-right">${{ copier.monthly_price }}/per-month</h3> -->
                <h3 style=""><b>{{ copier.category_name }}</b></h3>
                <h4>{{ copier.copier_model }}</h4>
                <h4>{{ copier.used_by }}</h4>
                <p>Color copier and prints {{ copier.print_page_per_minute }} pages per minute.For less than {{ copier.monthly_pages }} pages per month.</p>
                <p>{{ copier.price_color_page }} Cents per color page,{{ copier.price_bw_page }} cents per black & white page.Includes all service and supplies.</p>


        <a type="button" href="#/pull-details/{{copier.id}}" style="background:#00578d;" class="btn btn-info btn-lg">Get details</a>
      </div>
      </div>
      </div>

    </div>
    <div class="col-sm-2"></div>
  </div>
</div>

</body>
