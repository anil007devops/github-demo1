<?php include 'admin-header.html';?>

<style>
#rcorners6 {
    border-radius: 15px 50px;
    background: #00578d;
    padding: 20px;
    color:#fff;

}

.input-lg {
    height: 46px;
    padding: 10px 16px;
    font-size: 15px;
    line-height: 1.3333333;
    border-radius: 6px;
}
/* Overriding styles */

::-webkit-input-placeholder {
   font-size: 15px!important;

}

:-moz-placeholder { /* Firefox 18- */
      font-size: 15px!important;
}
::-moz-placeholder {  /* Firefox 19+ */
      font-size: 15px!important;
}

</style>
<div class="container-fluid">

  <div class="row">
  <br>
  <div class="col-sm-3" style="border-right:px solid #000;">
    <div class="well">
        <button style="margin-bottom:20px;background:#337ab7;" type="button" class="btn btn-info btn-lg btn-block">Manage copier details</button>
    <ul class="list-group">
      <li class="list-group-item"><a href="#/add-categories">Categories</a></li>
      <li class="list-group-item"><a href="#/add-copiers">Copiers</a></li>
      <li class="list-group-item"><a href="#/add-accessories">Accessories</a></li>
      <li class="list-group-item"><a href="#/add-payments">Plan details</a></li>
      <li class="list-group-item"><a href="#/add-crystalball-service">Copier service details</a></li>
   <li class="list-group-item"><a href="#/add-pricing-policy">CrystalBall fair pricing policy</a></li>
    </ul>
  </div>
  </div>

  <div class="col-sm-9">
  <div class="table-responsive">
  <table class="table table-striped" style="border:1px solid #999;">
    <h3 style="margin-top:1px;"class="pull-left">Accessories</h3>
    <button style="margin-bottom:20px;background:#337ab7;" type="button" class="btn btn-info btn-lg pull-right" data-toggle="modal" data-target="#myModal">Add accessory</button>
<thead>
  <tr style="background:#337ab7;">
  <th>Accessory name</th>
  <th>Accessory price</th>
  <!-- <th>Created_at</th>
  <th>Updated_at</th> -->
  <th>Action</th>
  </tr>
</thead>
<tbody ng-repeat="accessory in accessories">
  <tr>
  <td>{{ accessory.accessory_name}}
  <a style="text-decoration:none;" href="" id="flip" ng-click="clickAccessory(accessory.id)">
   <span class="glyphicon glyphicon-triangle-bottom"></span></a>

  </td>
  <!-- <td>{{copier.category_name}}</td> -->
  <td>${{accessory.price}}</td>

  <td  style="white-space: nowrap">
  <a data-toggle="tooltip" title="Edit"><span ng-click="toggle(accessory)" class="glyphicon glyphicon-pencil"></span></a> &nbsp;
  <a data-toggle="tooltip" title="Delete"><span ng-click="disableAccessory(accessory.id)" class="glyphicon glyphicon-trash"></span></a>
 </td>
  </tr>

<div ng-if="showCopier==true">
<tr id="{{accessory.id}}" class="hide">
  <td colspan="3">
    <table class="table table-bordered">
       <thead>
         <tr>
           <th>Copier Name  <a style="text-decoration:none;" href="" id="flip" ng-click="hideNow()">
             <span class="glyphicon glyphicon-triangle-top"></span></a></th>
         </tr>
       </thead>
       <tbody ng-repeat="cop in copiers1">
        <tr>
          <td>{{cop.copier_model}}</td></td>
        </tr>
      </tbody>
    </table>
  </td>
</tr>
</div>

</tbody>
  </table>
  </div>
  </div>
  <!-- <div class="col-sm-3"></div>
  <div class="col-sm-9">
  <div ng-if="copiers1">
  <h4 style="line-height:30px;color:#337ab7;">Accessory belongs to following copiers :</h4>
  <div>
  <div class="table-responsive">
<table class="table table-bordered">
<tr class="info"><th>copier Name</th></tr>
<tr ng-repeat="cop in copiers1"><td><span class="glyphicon glyphicon-stop"></span> {{cop.copier_model}}</td></tr>
</table>
  </div>
  <!- <ul class="list-inline">
  <li class="pull-left">
  <span class="glyphicon glyphicon-stop"></span> {{cop.copier_model}}
  </li>
  </ul> -->
  <!-- </div>
  </div> -->
<!-- </div> -->
  </div>
  <!-- end table view-->

  <!-- Modal -->
  <div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">
      <!-- Modal content-->
     <div class="modal-content">
       <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal">&times;</button>
         <h4 class="modal-title">Add accessories for all copiers</h4>
       </div>
       <div class="modal-body">
    <div class="row">
        <div class="col-xs-12 col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-3">
            <form role="form">
                <h4 id="rcorners6">Accessories details :</h4>
                <hr class="colorgraph">

                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-6">
                        <div class="form-group">
                            <label for="accessory_name">Accessory name/model</label>
                            <input type="text" ng-model="accessory.accessory_name" id="accessory_name" class="form-control input-lg" placeholder="Accessory name" tabindex="5">
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-6">
                        <div class="form-group">
                            <label for="price">Accessory price</label>
                            <input type="text" ng-model="accessory.price" id="price" class="form-control input-lg" placeholder="Accessory price" tabindex="6">
                        </div>
                    </div>
                </div>

                <div class="row">
                  <div class="col-xs-12 col-md-12">
                     <label>Select associated copiers(hold shift to select more than one)</label>
                     <select multiple class="form-control input-lg" multiple="multiple" ng-model="accessory.copiers">
                       <!-- <option value="">Select copier</option> -->
                       <option value='{{copier.id}}' ng-repeat="copier in copiers">{{copier.copier_model}}</option>
                     </select>
                  </div>
                </div>

                    <div class="row">
                      <div class="col-xs-12 col-md-12">
                        <br>
                        <button type="submit" ng-click="addAccessory()" data-dismiss="modal" style="background: #00578d;" class="btn btn-primary btn-block btn-lg" tabindex="11">Submit</button>
                      </div>
                          <input type="hidden" name="_token" value="{{ csrf_token() }}">
                  </div>
                      </form>
                      <br><br>
                    </div>
                    </div>
                  </div><!--modal body closed-->
                  <div class="modal-footer">
                         <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                       </div>
                     </div>

                  </div>
                  </div><!--end of the model -->

                  <!-- Modal2 for edit -->
                  <div id="myModal2" class="modal fade" role="dialog">
                    <div class="modal-dialog modal-lg">
                      <!-- Modal content-->
                     <div class="modal-content">
                       <div class="modal-header">
                         <button type="button" class="close" data-dismiss="modal">&times;</button>
                         <h4 class="modal-title">Add accessories for all copiers</h4>
                       </div>
                       <div class="modal-body">
                    <div class="row">
                        <div class="col-xs-12 col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-3">
                            <form role="form">
                                <h4 id="rcorners6">Accessories details :</h4>
                                <hr class="colorgraph">

                                <div class="row">
                                    <div class="col-xs-12 col-sm-6 col-md-6">
                                        <div class="form-group">
                                            <label for="accessory_name">Accessory name/model</label>
                                            <input type="text" ng-model="editaccessories.accessory_name" id="accessory_name" class="form-control input-lg" placeholder="Accessory name" tabindex="5">
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-6 col-md-6">
                                        <div class="form-group">
                                            <label for="price">Accessory price</label>
                                            <input type="text" ng-model="editaccessories.price" id="price" class="form-control input-lg" placeholder="Accessory price" tabindex="6">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                  <div class="col-xs-12 col-md-12">
                                     <label>Select associated copiers(hold shift to select more than one)</label>
                                     <select multiple class="form-control input-lg" multiple="multiple" ng-model="editaccessories.copiers">
                                       <!-- <option value="">Select copier</option> -->
                                       <option value='{{copier.id}}' ng-repeat="copier in copiers">{{copier.copier_model}}</option>
                                     </select>
                                  </div>
                                </div>

                                    <div class="row">
                                      <div class="col-xs-12 col-md-12">
                                        <br>
                                        <button type="submit" ng-click="editAccessory(editaccessories,editaccessories.id)" data-dismiss="modal" style="background: #00578d;" class="btn btn-primary btn-block btn-lg" tabindex="11">Submit</button>
                                      </div>
                                          <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                  </div>
                                      </form>
                                      <br><br>
                                    </div>
                                    </div>
                                  </div><!--modal body closed-->
                                  <div class="modal-footer">
                                         <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                       </div>
                                     </div>

                                  </div>
                                  </div><!--end of the model -->


                </div><!-- closed main container -->
