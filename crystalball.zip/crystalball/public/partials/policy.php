<?php include 'admin-header.html';?>

<style>
#rcorners6 {
    border-radius: 15px 50px;
    background: #00578d;
    padding: 20px;
    color:#fff;

}

.input-lg {
    height: 46px;
    padding: 10px 16px;
    font-size: 15px;
    line-height: 1.3333333;
    border-radius: 6px;
}
/* Overriding styles */

::-webkit-input-placeholder {
   font-size: 15px!important;

}

:-moz-placeholder { /* Firefox 18- */
      font-size: 15px!important;
}
::-moz-placeholder {  /* Firefox 19+ */
      font-size: 15px!important;
}
.sidebar-nav-fixed {
width:23%;

}
</style>
<div class="container-fluid">

  <div class="row">
  <br>

  <div class="col-sm-3" style="border-right:px solid #000;">

    <div class="well">
        <button style="margin-bottom:20px;background:#337ab7;" type="button" class="btn btn-info btn-lg btn-block">Manage copier details</button>
    <ul class="list-group">
      <li class="list-group-item"><a href="#/add-categories">Categories</a></li>
      <li class="list-group-item"><a href="#/add-copiers">Copiers</a></li>
      <li class="list-group-item"><a href="#/add-accessories">Accessories</a></li>
      <li class="list-group-item"><a href="#/add-payments">Plan details</a></li>
      <li class="list-group-item"><a href="#/add-crystalball-service">Copier service details</a></li>
      <li class="list-group-item"><a href="#/add-pricing-policy">CrystalBall fair pricing policy</a></li>
    </ul>
  </div>
  </div>

  <div class="col-sm-9">
  <div class="table-responsive">
  <table class="table table-striped" style="border:1px solid #999;">
  <h3 style="margin-top:1px;"class="pull-left">Crystalball fair pricing policy</h3>
  <button style="margin-bottom:20px;background:#337ab7;" type="button" class="btn btn-info btn-lg pull-right" data-toggle="modal" data-target="#myModal">Add policy</button>
  <tr style="background:#337ab7;color:#fff;">
  <th>Policy description</th>
  <!-- <th>Performance category</th> -->
  <!-- <th>Created_at</th>
  <th>Updated_at</th> -->
  <th>Action</th>
  </tr>
  <tr ng-repeat="policy in crystalballpolicy">
  <td>{{policy.policy_description}}</td>
  <!-- <td>{{copier.category_name}}</td> -->
  <!-- <td>{{category.created_at}}</td>
  <td>{{category.updated_at}}</td> -->
  <td>
    <a data-toggle="tooltip" title="Edit"><span  ng-click="toggle(policy)" class="glyphicon glyphicon-pencil"></span></a> &nbsp;
    <a data-toggle="tooltip" title="Delete"><span ng-click="disablePolicy(policy.id)" class="glyphicon glyphicon-trash"></span></a>
  </td>
  </tr>
  </table>
  </div>
  </div>

</div>
  <!-- end table view-->

  <!-- add category Modal -->

  <div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">
      <!-- Modal content-->
     <div class="modal-content">
       <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal">&times;</button>
         <h4 class="modal-title">Describe crystalball policy</h4>
       </div>
       <div class="modal-body">
<div class="row">
<div class="col-xs-12 col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-3">

<form role="form">
  <h4 id="rcorners6">Policy details :</h4>
   <hr class="colorgraph">

<div class="form-group">
  <label for="category_name">Policy</label>
  <textarea  rows="5" ng-model="policy.policy_description" id="policy" class="form-control input-lg"></textarea>
</div>

<div class="row">
  <div class="col-xs-12 col-md-12">
  <button type="submit" ng-click="addPolicy()" data-dismiss="modal" style="background: #00578d;" class="btn btn-primary btn-block btn-lg" tabindex="11">Submit</button>
</div>
  <input type="hidden" name="_token" value="{{ csrf_token() }}">
</div>
</form>

</div>
</div>
</div><!--modal body closed-->
<div class="modal-footer">
       <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
     </div>
   </div>

</div>
</div><!--end of the model -->


<!-- edit category Modal -->
<div id="myModal2" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">
    <!-- Modal content-->
   <div class="modal-content">
     <div class="modal-header">
       <button type="button" class="close" data-dismiss="modal">&times;</button>
       <h4 class="modal-title">Edit crystallball policy</h4>
     </div>
     <div class="modal-body">
<div class="row">
<div class="col-xs-12 col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-3">

<form role="form">
<h4 id="rcorners6">Policy details :</h4>
 <hr class="colorgraph">

<div class="form-group">
<label for="category_name">Policy</label>
<textarea ng-model="editpolicy.policy_description" rows="5" class="form-control input-lg"></textarea>
</div>
<div class="row">
<div class="col-xs-12 col-md-12">
<button type="submit" ng-click="editPolicy(editpolicy,editpolicy.id)" data-dismiss="modal" style="background: #00578d;" class="btn btn-primary btn-block btn-lg" tabindex="11">Submit</button>
</div>
<input type="hidden" name="_token" value="{{ csrf_token() }}">
</div>
</form>

</div>
</div>
</div><!--modal body closed-->
<div class="modal-footer">
     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
   </div>
 </div>

</div>
</div><!--end of the model -->


</div><!-- closed main container -->
