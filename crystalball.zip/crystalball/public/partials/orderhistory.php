<?php include 'user-header.html';?>
<br><br><br><br><br><br>
<div class="container">
<div class="col-lg-12 col-md-12 col-sm-12">
<h3 style="color:#337ab7;">Order history</h3>
<div class="table-responsive">
<table class="table table-bordered">
  <thead>
    <th>Copier model/name</th>
    <th>Order Date</th>
      <th>Details</th>
  </thead>
  <tbody ng-repeat="order in orderhistory">
    <tr>
      <td>{{order.copier_model}}</td>
        <td>{{order.order_date}}</td>
          <td><a href="">Details</a></td>
    </tr>
  </tbody>
  </table>
  </div>
  </div>
  </div>
