<?php include 'admin-header.html';?>

<style>
#rcorners6 {
    border-radius: 15px 50px;
    background: #00578d;
    padding: 20px;
    color:#fff;

}

.input-lg {
    height: 46px;
    padding: 10px 16px;
    font-size: 15px;
    line-height: 1.3333333;
    border-radius: 6px;
}
/* Overriding styles */

::-webkit-input-placeholder {
   font-size: 15px!important;

}

:-moz-placeholder { /* Firefox 18- */
      font-size: 15px!important;
}
::-moz-placeholder {  /* Firefox 19+ */
      font-size: 15px!important;
}

</style>
<div class="container-fluid">
    <div class="row">
    <br>
    <div class="col-sm-3" style="border-right:px solid #000;">
      <div class="well">
      <button style="margin-bottom:20px;background:#337ab7;" type="button" class="btn btn-info btn-lg btn-block">Manage copier details</button>
      <ul class="list-group">
        <li class="list-group-item"><a href="#/add-categories">Categories</a></li>
        <li class="list-group-item"><a href="#/add-copiers">Copiers</a></li>
        <li class="list-group-item"><a href="#/add-accessories">Accessories</a></li>
        <li class="list-group-item"><a href="#/add-payments">Plan details</a></li>
        <li class="list-group-item"><a href="#/add-crystalball-service">Copier service details</a></li>
        <li class="list-group-item"><a href="#/add-pricing-policy">CrystalBall fair pricing policy</a></li>
      </ul>
    </div>
    </div>

    <div class="col-sm-9">
    <div class="table-responsive">
    <table class="table table-striped" style="border:1px solid #999;">
      <h3 style="margin-top:1px;"class="pull-left">Payment plans/options</h3>
      <button style="margin-bottom:20px;background:#337ab7;" type="button" class="btn btn-info btn-lg pull-right" data-toggle="modal" data-target="#myModal">Add plan</button>

    <tr style="background:#337ab7;">
    <th>Copier model</th>
    <th>Category</th>
    <th>No of lease months</th>
    <th>Price per lease month</th>
     <th>Support price</th>
    <th>Delivery price</th>
    <th>Pickup price</th>
    <th>Action</th>
    </tr>
    <tr ng-repeat="payment in payments">

    <td>{{ payment.copier_model}}</td>

    <td>{{ payment.category_name}}</td>

    <td>{{ payment.no_of_months}}</td>

    <td>${{payment.price_per_month}}</td>

    <td>
    <div ng-if="payment.support_price != 0">
      ${{payment.support_price}}
    </div>
    <div ng-if="payment.support_price == 0">
      <p>Free</p>
     </div>
     </td>

    <td>
    <div ng-if="payment.delivery_price != 0">
      ${{payment.delivery_price}}
    </div>
    <div ng-if="payment.delivery_price == 0">
    <p>Free</p>
    </div>
    </td>

      <td>
      <div ng-if="payment.pickup_price != 0">
      ${{payment.pickup_price}}
      </div>
      <div ng-if="payment.pickup_price == 0">
      <p>Free</p>
      </div>
      </td>

    <td>
        <a data-toggle="tooltip" title="Edit"><span ng-click="toggle(payment)" class="glyphicon glyphicon-pencil"></span></a> &nbsp;
      <a data-toggle="tooltip" title="Delete"><span ng-click="disablePayment(payment.id)" class="glyphicon glyphicon-trash"></span></a>

   </td>

    </tr>
    </table>
    </div>
    </div></div>
    <!-- end table view-->

    <!-- Modal -->
    <div id="myModal" class="modal fade" role="dialog">
      <div class="modal-dialog modal-lg">
        <!-- Modal content-->
       <div class="modal-content">
         <div class="modal-header">
           <button type="button" class="close" data-dismiss="modal">&times;</button>
           <h4 class="modal-title">Add payment details for copiers</h4>
         </div>
         <div class="modal-body">
    <div class="row">
        <div class="col-xs-12 col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-3">
            <form role="form">
                <h4 id="rcorners6">Lease payment details for copiers:</h4>
                <p>Select the copier categories for lease and set the payment options accordingly</p>
                <hr class="colorgraph">

                <div class="form-group">

                    <label for="plan">Select copier name/model</label>
                    <select  class="form-control input-lg" id="plan" name="plan" ng-model="copier.id">
                    <option value="">Select copier</option>
                    <option value="{{copier1.id}}" ng-repeat="copier1 in copiers">{{copier1.copier_model}}</option>

                    </select>
                </div>

                 <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-6">
                      <div class="form-group">
                          <label for="no_of_months">Select lease months</label>
                          <select  class="form-control input-lg" id="no_of_months" ng-model="copier.no_of_months">
                          <option value="">Select lease months</option>
                          <option value="1">1 month</option>
                          <option value="12">12 months</option>
                          <option value="24">24 months</option>
                          </select>
                      </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-6">
                        <div class="form-group">
                            <label for="price_per_month">Price per Month</label>
                            <input type="text" name="price_per_month" ng-model="copier.price_per_month" id="price_per_month" class="form-control input-lg" placeholder="Price per month" tabindex="6">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-6">
                        <div class="form-group">
                            <label for="support_price">Support price</label>
                            <input type="text" name="support_price" ng-model="copier.support_price" id="support_price" class="form-control input-lg" placeholder="Support price" tabindex="5">
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-6">
                        <div class="form-group">
                            <label for="delivery_price">Delivery Price</label>
                            <input type="text" name="delivery_price" ng-model="copier.delivery_price" id="delivery_price" class="form-control input-lg" placeholder="Delivery price" tabindex="6">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="pickup_price">Pickup price</label>
                    <input type="text" name="pickup_price" ng-model="copier.pickup_price" id="pickup_price" class="form-control input-lg" placeholder="Pickup price" tabindex="8">
                </div>



                <div class="row">
                  <div class="col-xs-12 col-md-12">
                    <button type="submit"  ng-click="addPayment()" data-dismiss="modal" style="background: #00578d;" class="btn btn-primary btn-block btn-lg" tabindex="11">Submit</button>
                  </div>
                      <input type="hidden" name="_token" value="{{ csrf_token() }}">
                        </div>
                  </form>
                  <br><br>
                </div>
                </div>
              </div><!--modal body closed-->
              <div class="modal-footer">
                     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                   </div>
                 </div>

              </div>
              </div><!--end of the model -->

              <!-- Modal2 for edit -->
              <div id="myModal2" class="modal fade" role="dialog">
                <div class="modal-dialog modal-lg">
                  <!-- Modal content-->
                 <div class="modal-content">
                   <div class="modal-header">
                     <button type="button" class="close" data-dismiss="modal">&times;</button>
                     <h4 class="modal-title">Edit payment details for copiers</h4>
                   </div>
                   <div class="modal-body">
              <div class="row">
                  <div class="col-xs-12 col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-3">
                      <form role="form">
                          <h4 id="rcorners6">Lease payment details for copiers:</h4>
                          <p>Select the copier categories for lease and set the payment options accordingly</p>
                          <hr class="colorgraph">


                          <div class="form-group" ng-repeat="copier1 in copiers">
                            <div ng-if="editpayments.copier_id==copier1.id">
                                <label for="plan">Copier name/model</label>
                                <input type="text" class="form-control input-lg" ng-model="copier1.copier_model" disabled/>
                              <!-- <select class="form-control input-lg" id="category_name" ng-model="editPayments.idd" ng-required>
                              <option value="" disabled>Select copier</option>
                              <option value="{{copier1.id}}">{{copier1.copier_model}}</option>
                              </select> -->
                          </div>
                          </div>

                             <div class="row">
                              <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="form-group">
                                    <label for="no_of_months">Lease months</label>
                                    <input type="text" class="form-control input-lg" ng-model="editpayments.no_of_months" disabled/>
                                    <!-- <select  class="form-control input-lg" id="no_of_months" ng-model="editpayments.no_of_months">
                                    <option value="">Select lease months</option>
                                    <option value="1">Month to Month</option>
                                    <option value="12">12 Month</option>
                                    <option value="24">24 Month</option>
                                    </select> -->
                                </div>
                              </div>
                              <div class="col-xs-12 col-sm-6 col-md-6">
                                  <div class="form-group">
                                      <label for="price_per_month">Price per Month</label>
                                      <input type="text" ng-model="editpayments.price_per_month" class="form-control input-lg" placeholder="Price per month" tabindex="6">
                                  </div>
                              </div>
                          </div>

                          <div class="row">
                              <div class="col-xs-12 col-sm-6 col-md-6">
                                  <div class="form-group">
                                      <label for="support_price">Support price</label>
                                      <input type="text" ng-model="editpayments.support_price" class="form-control input-lg" placeholder="Support price" tabindex="5">
                                  </div>
                              </div>
                              <div class="col-xs-12 col-sm-6 col-md-6">
                                  <div class="form-group">
                                      <label for="delivery_price">Delivery Price</label>
                                      <input type="text" ng-model="editpayments.delivery_price" class="form-control input-lg" placeholder="Delivery price" tabindex="6">
                                  </div>
                              </div>
                          </div>

                          <div class="form-group">
                              <label for="pickup_price">Pickup price</label>
                              <input type="text" ng-model="editpayments.pickup_price" class="form-control input-lg" placeholder="Pickup price" tabindex="8">
                          </div>



                          <div class="row">
                            <div class="col-xs-12 col-md-12">
                              <button type="submit"  ng-click="editPayment(editpayments,editpayments.id)" data-dismiss="modal" style="background: #00578d;" class="btn btn-primary btn-block btn-lg" tabindex="11">Submit</button>
                            </div>
                                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                  </div>
                            </form>
                            <br><br>
                          </div>
                          </div>
                        </div><!--modal body closed-->
                        <div class="modal-footer">
                               <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                             </div>
                           </div>

                        </div>
                        </div><!--end of the model -->

              </div><!-- closed main container -->
