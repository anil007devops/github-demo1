<?php include 'admin-header.html';?>

<style>
#rcorners6 {
    border-radius: 15px 50px;
    background: #00578d;
    padding: 20px;
    color:#fff;

}

.input-lg {
    height: 46px;
    padding: 10px 16px;
    font-size: 15px;
    line-height: 1.3333333;
    border-radius: 6px;
}
/* Overriding styles */

::-webkit-input-placeholder {
   font-size: 15px!important;

}

:-moz-placeholder { /* Firefox 18- */
      font-size: 15px!important;
}
::-moz-placeholder {  /* Firefox 19+ */
      font-size: 15px!important;
}

</style>
<div class="container-fluid">

  <div class="row">
  <br>
  <div class="col-sm-3" style="border-right:px solid #000;">
    <div class="well">
        <button style="margin-bottom:20px;background:#337ab7;" type="button" class="btn btn-info btn-lg btn-block">Manage copier details</button>
    <ul class="list-group">
      <li class="list-group-item"><a href="#/add-categories">Categories</a></li>
      <li class="list-group-item"><a href="#/add-copiers">Copiers</a></li>
      <li class="list-group-item"><a href="#/add-accessories">Accessories</a></li>
      <li class="list-group-item"><a href="#/add-payments">Plan details</a></li>
      <li class="list-group-item"><a href="#/add-crystalball-service">Copier service details</a></li>
    <li class="list-group-item"><a href="#/add-pricing-policy">CrystalBall fair pricing policy</a></li>
    </ul>
  </div>
  </div>

  <div class="col-sm-9">
  <div class="table-responsive">
  <table class="table table-striped" style="border:1px solid #999;">
    <h3 style="margin-top:1px;"class="pull-left">Copier's services</h3>
    <button style="margin-bottom:20px;background:#337ab7;" type="button" class="btn btn-info btn-lg pull-right" data-toggle="modal" data-target="#myModal">Add service</button>

  <tr style="background:#337ab7;">
  <th>Copier name/model</th>
  <th>Service name</th>
  <!-- <th>Created_at</th>
  <th>Updated_at</th> -->
  <th>Action</th>
  </tr>
  <tr ng-repeat="service in crystalballservices">
  <td>{{ service.copier_model }}</td>
  <!-- <td>{{copier.category_name}}</td> -->
  <td>{{ service.service_name }}</td>

  <td>


    <a data-toggle="tooltip" title="Edit"><span ng-click="toggle(service)" class="glyphicon glyphicon-pencil"></span></a> &nbsp;
    <a data-toggle="tooltip" title="Delete"><span ng-click="disableCrystalballService(service.id)" class="glyphicon glyphicon-trash"></span></a>
 </td>

  </tr>
  </table>
  </div>
  </div></div>
  <!-- end table view-->

  <!-- Modal -->
  <div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">
      <!-- Modal content-->
     <div class="modal-content">
       <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal">&times;</button>
         <h4 class="modal-title">Add service for all copiers</h4>
       </div>
       <div class="modal-body">
    <div class="row">
        <div class="col-xs-12 col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-3">
            <form role="form">
                <h4 id="rcorners6">Services details :</h4>
                <hr class="colorgraph">

                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="form-group">
                            <label for="accessory_name">Service name</label>
                            <input type="text" ng-model="service.service_name" class="form-control input-lg" placeholder="Service name" tabindex="5">
                        </div>
                    </div>
                </div>

                <div class="row">
                  <div class="col-xs-12 col-md-12">
                    <p><b>Select the associated copiers to service:</b></p>
                    <div class="checkbox">
                     <label ng-repeat="copier in copiers">
                      <ul class="list-inline">
                      <li><input type="checkbox" checklist-model="service.copiers" checklist-value="copier.id">
                       {{copier.copier_model}}
                     </li>
                     </ul>
                     </label>
                   </div>

                  </div>
                </div>

                    <div class="row">
                      <div class="col-xs-12 col-md-12">
                        <button type="submit" ng-click="addCrystalballService()" data-dismiss="modal" style="background: #00578d;" class="btn btn-primary btn-block btn-lg" tabindex="11">Submit</button>
                      </div>
                          <input type="hidden" name="_token" value="{{ csrf_token() }}">
                  </div>
                      </form>
                      <br><br>
                    </div>
                    </div>
                  </div><!--modal body closed-->
                  <div class="modal-footer">
                         <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                       </div>
                     </div>

                  </div>
                  </div><!--end of the model -->

                  <!-- Modal for editing -->
                  <div id="myModal2" class="modal fade" role="dialog">
                    <div class="modal-dialog modal-lg">
                      <!-- Modal content-->
                     <div class="modal-content">
                       <div class="modal-header">
                         <button type="button" class="close" data-dismiss="modal">&times;</button>
                         <h4 class="modal-title">Edit service for all copiers</h4>
                       </div>
                       <div class="modal-body">
                    <div class="row">
                        <div class="col-xs-12 col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-3">
                            <form role="form">
                                <h4 id="rcorners6">Services details :</h4>
                                <hr class="colorgraph">

                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12">
                                        <div class="form-group">
                                            <label for="accessory_name">Service name</label>
                                            <input type="text" ng-model="editservices.service_name" class="form-control input-lg" placeholder="Service name" tabindex="5">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                  <div class="col-xs-12 col-md-12">
                                    <label>Select associated copiers(hold shift to select more than one)</label>
                                    <select multiple class="form-control input-lg" multiple="multiple" ng-model="editservices.copiers">
                                      <!-- <option value="">Select copier</option> -->
                                      <option value='{{copier.id}}' ng-repeat="copier in copiers">{{copier.copier_model}}</option>
                                    </select>

                                  </div>
                                </div>

                                    <div class="row">
                                      <div class="col-xs-12 col-md-12">
                                        <button type="submit" ng-click="editCrystalballService(editservices,editservices.id)" data-dismiss="modal" style="background: #00578d;" class="btn btn-primary btn-block btn-lg" tabindex="11">Submit</button>
                                      </div>
                                          <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                  </div>
                                      </form>
                                      <br><br>
                                    </div>
                                    </div>
                                  </div><!--modal body closed-->
                                  <div class="modal-footer">
                                         <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                       </div>
                                     </div>

                                  </div>
                                  </div><!--end of the model -->
                </div><!-- closed main container -->
