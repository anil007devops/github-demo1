<?php include('header2.html'); ?>
  <style>
  body {
      position: relative;
      top:50px;
  }

  #section1 {color: #; background-color: #1E88E5;margin:0px;}

  @media screen and (max-width: 810px) {
    #section1, #section2, #section3, #section41, #section42  {
        margin-left: 10px;

    }
  }
  .sidebar-nav-fixed {
	width:30%;


}

@media (max-width: 767px) {
     .sidebar-nav-fixed {
         width:auto;
     }
 }

 @media (max-width: 979px) {
     .sidebar-nav-fixed {
         position:static;
        width: auto;
     }
 }
  </style>

</head>
<body>
<div class="container-fluid">
<br><br><br><br>
  <div class="row" style="padding:20px;">

    <nav class="col-xs-12 col-sm-6 col-sm-5 text-center">
 <div class="sidebar-nav-fixed affix">
      <img src="images/copier44.jpg" class="img-responsive" style="margin-left:0px;margin-top:50px;"/>
  <a href=""><h4 class="text-center"><span class="glyphicon glyphicon-picture"></span> VIEW GALLERY</h4></a>
  <br><h4 class="text-center">Built-in Features</h4><br>
  <ul class="list-inline text-center">
    <li><h4><span class=" glyphicon glyphicon-th-large"></span><br> Color</h4></li>
    <li><h4><span class=" glyphicon glyphicon-cd"></span><br> Scan</h4></li>
    <li><h4><span class=" glyphicon glyphicon-copy"></span><br> Copy</h4></li>
    <li><h4><span class=" glyphicon glyphicon-envelope"></span><br> Email</h4></li>
    <li><h4><span class=" glyphicon glyphicon-print"></span><br> Print</h4></li>
  </ul>
</div>
    </nav>
    <div class="col-xs-12 col-sm-6 col-sm-6">
      <div>
        <div class="panel panel-default well">
            <div class="panel-body">
                <!-- <h3 style="" class="pull-right">${{ copier.monthly_price }}/per-month</h3> -->
                <h3 style=""><b>{{ copiers.category_name }}</b></h3>
                <h4>{{ copiers.copier_model }}</h4>
                <h4>{{ copiers.used_by }}</h4>
                <p>Color copier and prints {{ copiers.print_page_per_minute }} pages per minute.For less than {{ copiers.monthly_pages }} pages per month.</p>
                <p>{{ copiers.price_color_page }} Cents per color page,{{ copiers.price_bw_page }} cents per black & white page.Includes all service and supplies.</p>
                <h4><b>Accessories :</b></h4>
                <div class="checkbox">
                 <label ng-repeat="accessory in accessories">
                  <ul><li><input type="checkbox" data-checklist-model="user.accessories" data-checklist-value="accessory">
                   {{accessory.accessory_name}} &nbsp; ${{accessory.price}}</li></ul>
                 </label>
               </div>

               <h4><b>Payment Plan Options :</b></h4>
               <span ng-repeat="payment in payments">
               <div class="radio">
                 <ul class="pull-left">
                <li>
                   <div  ng-if="payment.no_of_months==1">
                <input type="radio" ng-model="user.payments" ng-value="{{payment}}">
                <p>Month to Month &nbsp; ${{payment.price_per_month}}/per month</p>
              </div>
              <div  ng-if="payment.no_of_months !=1">
           <input type="radio" ng-model="user.payments" ng-value="{{payment}}">
           {{payment.no_of_months}} Months&nbsp; ${{payment.price_per_month}}/per month
         </div>
                </li>
                <ul>
                  <li>Support Price ${{payment.support_price}}</li>
                  <li>Pickup Price ${{payment.pickup_price}}</li>
                  <li>Delivery Price ${{payment.delivery_price}}</li>
                </ul>
                </ul>
               </div>
             </span>

        <button type="button" style="background:#00578d;" class="btn btn-info btn-block pull-right" ng-click="summary(user)">GET IT NOW</button>
      </div>
    </div>
      </div>

    </div>
    <div class="col-sm-1"></div>
  </div>
</div>

</body>
