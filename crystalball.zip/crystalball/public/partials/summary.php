<?php include('header2.html'); ?>
  <style>
.list-group-item{
  padding:0px 15px;
  border:0px;
}
.ul1 {
    -moz-column-count: 4;
    -moz-column-gap: 20px;
    -webkit-column-count: 4;
    -webkit-column-gap: 20px;
    column-count: 4;
    column-gap: 20px;
}
  </style>

</head>
<body>
  <br><br><br>
<div class="container-fluid" ng-init="accessory_price_total = {}">
<br><br><br>
  <div class="row" style="padding:20px;">
      <div class="col-lg-2 col-md-2 col-sm-2"></div>
    <div class="col-lg-8 col-md-8 col-sm-8">
      <h2>Review your order</h2>
        <div class="panel panel-default well" style="background:#fff;">
            <div class="panel-body">
              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<div class="col-lg-3 col-md-3 col-sm-3"><img class="img-responsive" src="images/copier11.jpg" style="height:270px;width:200px;"></div>
<div class="col-lg-9 col-md-9 col-sm-9">
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12">
<div class="col-lg-9 col-md-9 col-sm-9">

<h3><b>{{summaries.copiers.category_name}}</b></h3>
<h4><b>{{summaries.copiers.copier_model}} {{ summaries.copiers.used_by }}</b></h4>
<p>Color copier and prints {{ summaries.copiers.print_page_per_minute }} pages per minute.For less than {{ summaries.copiers.monthly_pages }} pages per month.</p>
<p>{{ summaries.copiers.price_color_page }} Cents per color page,{{ summaries.copiers.price_bw_page }} cents per black & white page.Includes all service and supplies.</p>
<p><b><span class="glyphicon glyphicon-hand-right"></span> CrystalBall Service includes :</b></p>
<div class="col-lg-12 col-md-12 col-sm-12 well">
<ul class="list-group" ng-repeat="crystal in crystalballservices1">
<li class="list-group-item"><span class="glyphicon glyphicon-ok-sign"></span> {{crystal.service_name}}</li>
</ul>
</div><!--inside col-12 closed -->
<div class="col-lg-12 col-md-12 col-sm-12">
<div ng-if="summaries.payments.no_of_months !=1">
<p><span class="glyphicon glyphicon-stop"></span>
You choose {{summaries.payments.no_of_months}} months plan - you agree to keep this machine
for {{summaries.payments.no_of_months}} months, after which it continues as a month to month rental until you cancel.</p>
</div>
</div>

<div ng-if="summaries.payments.no_of_months ==1">
<p><span class="glyphicon glyphicon-stop"></span>
You choose Month to Month plan - Cancel any time.</p>
</div>


<p><b><span class="glyphicon glyphicon-hand-right"></span> CrystalBall Fair Pricing Policy :</b></p>
<p ng-repeat="policy in crystalballpolicy">{{policy.policy_description}}</p></div>
<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3"><h4 style="" class="pull-right"><b>${{ summaries.payments.price_per_month }}/per month</b></h4></div></div>
</div>
</div><!--inner row closed-->
</div>
</div><!--closed panel body-->
<hr>

<div class="row"><div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
  <h4><b>Accessories :</b></h4>
    <div ng-if="!summaries.accessories">
  <p>No accessories added</p>
    </div>
      <div ng-if="summaries.accessories">
  <span ng-repeat="accessory in summaries.accessories">
    <ul class="list-group"><li class="list-group-item">
      <h4 class="pull-right"><b ng-init="accessory_price_total.accessory.price = accessory_price_total.accessory.price + accessory.price">${{accessory.price}}/per month</b></h4>
  <p><span class="glyphicon glyphicon-stop"></span> {{accessory.accessory_name}}</p>
      </li></ul>
  </span>
  <!-- {{accessory_price_total.accessory.price}}  this is total of accessory price calculate just above print it where require-->
</div>
</div>
</div>

<hr>

<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <h4><b>One-time Charges :</b></h4>
      <ul class="list-group"><li class="list-group-item">
        <h4 class="pull-right">
        <div ng-if="summaries.payments.support_price==0">
        <b><p>Free</p>
        </div>
        <div ng-if="summaries.payments.support_price !=0">
        <p>${{summaries.payments.support_price}}</p>
        </div>

        <div ng-if="summaries.payments.delivery_price==0">
        <p>Free</p>
        </div>
        <div ng-if="summaries.payments.delivery_price !=0">
        <p>${{summaries.payments.delivery_price}}</p>
        </div>

        <div ng-if="summaries.payments.pickup_price==0">
        <p>Free</p>
        </div>
        <div ng-if="summaries.payments.pickup_price !=0">
        <p>${{summaries.payments.pickup_price}}</p>
        </div>
        </b></h4>
        <p><span class="glyphicon glyphicon-stop"></span> 2 hours of remote setup support </p>
        <p><span class="glyphicon glyphicon-stop"></span> Machine delivery</p>
        <p><span class="glyphicon glyphicon-stop"></span> Machine pickup</p>
        </li>
      </ul>
    <div ng-if="summaries.payments.no_of_months ==1">
      <p>By choosing Month-to-Month, you agree to a pickup charge of $ when you cancel.
        We will waive this charge if you keep the machine for at least 12 months.</p>
      </div>
</div>
</div>

<hr>
<div class="row"><div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<h4><b>What we'll charge now :</b></h4>
<h4 class="pull-right">Total : ${{summaries.payments.support_price + summaries.payments.delivery_price + summaries.payments.pickup_price + summaries.payments.price_per_month + accessory_price_total.accessory.price}}
</h4>
<p><span class="glyphicon glyphicon-stop"></span> ${{summaries.payments.support_price + summaries.payments.delivery_price + summaries.payments.pickup_price}}(One time charge);</p>
<p><span class="glyphicon glyphicon-stop"></span> ${{ summaries.payments.price_per_month }} (Monthly rental fee)</p>

<div ng-if="summaries.accessories">
<p><span class="glyphicon glyphicon-stop"></span>
${{accessory_price_total.accessory.price}} (monthly accessories fee)</p>
<p>Month 1 total:
${{summaries.payments.support_price + summaries.payments.delivery_price + summaries.payments.pickup_price + summaries.payments.price_per_month + accessory_price_total.accessory.price}}
+ Copy charges are billed in arrears(+ taxes,if applicable)</p>
</div>
</div>
</div>

<hr>
<!--row -->
<div class="row"><div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<h4><b>What we'll charge every month after that :</b></h4>
<p><span class="glyphicon glyphicon-stop"></span> ${{ summaries.payments.price_per_month }} (Monthly rental fee)</p>
<p><span class="glyphicon glyphicon-stop"></span> ${{accessory_price_total.accessory.price}} (monthly accessories fee)</p>
<p>Month 2 and later : ${{ summaries.payments.price_per_month + accessory_price_total.accessory.price }}
+ Copy charges are billed in arrears(+ taxes,if applicable)</p>
<ul class="list-group">
<li class="list-group-item">
<a type="button" href="#/userdetails" class="btn btn btn-lg btn-primary pull-right" style="width:150px;margin:29px;">Check Out</a>
<a type="button" href="#/copiers" class="btn btn btn-lg btn-primary" style="width:150px;margin:29px;">Back</a>
</li>
</ul>
</div>
</div><!--row --->


    </div>
    </div>
  <div class="col-lg-2 col-md-2 col-sm-2"></div>
  </div>
</div>

</body>
