
<?php include 'header2.html';?>

<style>
body {
    position: relative;
    top:50px;
}
</style>

<body>
<div class="container">
    <div class="row" style="padding-top:90px;">
        <div class="col-sm-3"></div>
        <div class="col-sm-6">
            <div class="well center_div">
                <div class="alert" ng-show="flash" ng-bind="flash"></div>
                <form name="loginForm" class="form-signin" method="post" ng-submit="login(loginForm)">
                    <h2 class="form-signin-heading"><img src="images/crystal2.png" class="img-responsive"/></h2>
                    <div class="input-group">
                        <label for="email" class="sr-only">Email address</label>
                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                        <input type="email" ng-model="user.email" id="email" class="form-control" placeholder="Email address" required autofocus>
                    </div>
                    <div class="input-group">
                        <label for="password" class="sr-only">Password</label>
                        <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                        <input type="password" ng-model="user.password" id="password" class="form-control" placeholder="Password" >
                    </div>
                    <br>
                    <div class="col-sm-6">
                        <label>
                            <input type="checkbox" value="remember-me"> Remember
                        </label>
                    </div>

                    <div class="col-sm-6">

                        <a  href="#">Forgot Password?</a>

                    </div>
                    <br><br>
                    <button class="btn btn-lg btn-primary btn-block" type="submit">Login</button>
                    <!--<input type="hidden" name="_token" value="{{ csrf_token() }}">-->
                </form>


            </div>

        </div>
        <div class="col-sm-3"></div>
    </div>


</div>
</body>
