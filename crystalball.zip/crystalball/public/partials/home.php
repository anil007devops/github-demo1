<?php include('header2.html'); ?>
<style>
.col-sm-6>img
{
    float:left;
    width:100%;

}
body {
    position: relative;
    top:70px;
}
</style>
<body>
<div class="container">
<br><br>
<div class="row">
    <div class="col-sm-6">
        <h1><b>Get Your commitment-free Copier Today</b></h1><br>
        <h3>Month to Month,No Lease,No Strings attached.</h3>
        <h3>Upgrade, Downgrade, Cancel any time.</h3>
<br><br>
        <a href="#/copiers" class="btn btn-primary btn-lg">GET PRICE QUOTES</a>
    </div>
    <div class="col-sm-6 text-center"><img class="img-responsive" src="images/copier123.jpg"/></div>
</div>

</div>
</body>
