<?php include 'header2.html';?>
<br><br>
<div class="container">
  <br><br><br><br>
<div class="row">
<div class="col-sm-12">
<h4>Thank You for your order. Our representative will get back to you.
We mailed you login credentials along with order summary.</h4>
<br><br>
<p>Please check your inbox for credentials to login.</p>
<br><br>
<p><a href="#/login">Go back to login</a></p>
</div>
</div>
</div>
