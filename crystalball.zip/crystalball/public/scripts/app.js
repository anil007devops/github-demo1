
(function() {
    'use strict';
    angular
        .module('App',  ['ui.router','checklist-model','xeditable']);




})();
