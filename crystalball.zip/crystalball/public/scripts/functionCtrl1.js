(function(){

    'use strict';
    angular
        .module('App')
        .controller('LoginController',loginCtrl)
        .controller('SignupController',signupCtrl)
        .controller('MainController', mainCtrl)
        .controller('LogoutController',logoutCtrl)
        .controller('ProductController',productCtrl)
        .controller('UserController',userCtrl)
        .controller('CopierController',copierCtrl)
        .controller('AccessoryController',accessoryCtrl)
        .controller('CategoryController',categoryCtrl)
        .controller('PaymentController',paymentCtrl)
        .controller('SummaryController',summaryCtrl)
        .controller('GetAllProductInfoController',GetAllProductInfoCtrl)
        .controller('CrystalballServiceController',CrystalballServiceCtrl)
        .controller('CrystalballPolicyController',crystalballPolicyCtrl)
        .controller('OrderHistoryController',orderHistoryCtrl)
        .constant('API_URL','http://192.168.11.117/crystalball/public/');

    loginCtrl.$inject = ['$scope','$location','$http','$rootScope','API_URL'];
    function loginCtrl($scope,$location,$http,$rootScope,API_URL){


         var vm = $scope;
         vm.user = {};
        vm.loginError = "";
       // console.log(vm.user);

        vm.login = function(loginForm){

  $http({

    headers:{
        'content-Type': 'application/json'
    },
    url: API_URL + 'auth',
    method: "POST",
    data: {
        email:$scope.user.email,
        password:$scope.user.password
    }
}).success(function(response){
      //console.log(JSON.stringify(response));
      console.log(response);
      //console.log(response.user[0].role_name);
      //console.log(response.user[0].id);

      //console.log(JSON.parse(sessionStorage.getItem("userId")));

      if(response.doesnotexist != "doesnotexist"){
        var name = response.user[0].role_name;
        sessionStorage.setItem("userId", JSON.stringify(response.user[0].id));
      if(name == "Admin"){
          $location.path('/admin-dashboard');
       }
       else{
          $location.path('/user-dashboard');
       }
     }
     else{
       alert("User account does not exist,Please register first");
     }

}).error(function(data,status,headers){
    console.log(data,status,headers);
    alert(data);
});

        }

    }



    signupCtrl.$inject = ['$scope','$location','$http','$rootScope','API_URL'];
    function signupCtrl($scope,$location,$http,$rootScope,API_URL) {

      //Addin record
        var vm = $scope;
         vm.user = {};
        vm.registerError = "";

      $scope.register = function() {
          console.log(vm.user);

          $http({

              headers:{
                  'content-Type': 'application/json'
              },
              url: API_URL + 'signup',      //baseUrl defined in index page
              method: "POST",
              data: {
                  email:$scope.user.email,
                  password:$scope.user.password,
                  first_name:$scope.user.first_name,
                  last_name:$scope.user.last_name,
                  phone_no:$scope.user.phone_no,
                  company_name:$scope.user.company_name,
                  address:$scope.user.address,
                  city:$scope.user.city,
                  state:$scope.user.state,
                  zipcode:$scope.user.zipcode,


              }
          }).success(function(response){
              console.log(response);
              $location.path('/login');
          }).error(function(data,status,headers){
              console.log(data,status,headers);
              alert(data);
          });
              }
      }


/* copier controller */
          copierCtrl.$inject = ['$scope','$location','$http','$rootScope','API_URL'];
          function copierCtrl($scope,$location,$http,$rootScope,API_URL) {

            //Addin copier records
              var vm = $scope;
               vm.copier = {};
              vm.copierError = "";

              //get product details
              $http.get(API_URL + 'copiers')
              .success(function (response,data) {
               //console.log(response);
              $scope.copiers = response.copiers;
              }).error(function (response) {
                alert('Not responding');
              });

              //below function can be call for refresh or reload the page for copiers
              vm.getCopier = function() {
               $http.get(API_URL + 'copiers')
               .success(function (response,data) {
                //console.log(response);
               $scope.copiers = response.copiers;
               }).error(function (response) {
                 alert('Not responding');
               });
              }

              // //toggle function
              // $scope.toggle = function(copier) {
              //   console.log(copier);
              //  // console.log(JSON.stringify(category));
              //  $scope.editcopiers = copier;
              //  $('#myModal2').modal('show');
              // }
              // $scope.showCategory= false;
              //  $scope.clickCopier = function(id){
              //    console.log(id);
              //    $scope.catid = id;
              //    $scope.showCategory=true;
              //  }
              //edit copiers
              $scope.editCopiers = function(response,id) {
                $scope.copiers= response;
                console.log($scope.copiers);
                $http({
                           method: 'POST',
                           url: API_URL + 'copiers/'+ id,
                           data: $.param($scope.copiers),
                           headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                       }).success(function(response) {
                           console.log(response);
                           vm.getCopier();
                       }).error(function(response) {
                           console.log(response);
                           alert('This is embarassing. An error has occured. Please check the log for details');
                       });

                      }

                      $scope.disableCopiers = function(id) {
                      console.log(id);
                       $http.post(API_URL + 'delete-copiers/' + id)
                       .success(function (response,data) {
                          //alert('Delete successfully');
                            vm.getCopier();
                       }).error(function (response) {
                         alert('Not responding');
                       });
                      }

              //get categories details and show in modal while add copiers
              $http.get(API_URL + 'categories')
                  .success(function (response,data) {
                    //console.log(response);
                   $scope.categories = response.categories;
                 }).error(function (response) {
                 alert('Not responding');
               });

                     //adding copiers
            $scope.addcopier = function() {
                console.log(vm.copier);
                $http({

                    headers:{
                        'content-Type': 'application/json'
                    },
                    url: API_URL + 'add-copiers',
                    method: "POST",
                    data: {
                        copier_model:$scope.copier.copier_model,
                        id:$scope.copier.id,
                        monthly_pages:$scope.copier.monthly_pages,
                        print_page_per_minute:$scope.copier.print_page_per_minute,
                        price_color_page:$scope.copier.price_color_page,
                        price_bw_page:$scope.copier.price_bw_page,
                        used_by:$scope.copier.used_by,
                        monthly_price:$scope.copier.monthly_price,

                    }
                }).success(function(response){
                    console.log(response);
                    if(response.exists != "exist"){
                        vm.getCopier();
                    }
                    else{
                      alert('Copier already present and it can be associated with only one category');
                    }
                }).error(function(data,status,headers){
                    console.log(data,status,headers);
                    alert(data);
                });
                    }

               }
/* end of copier controller */


      accessoryCtrl.$inject = ['$scope','$location','$http','$rootScope','API_URL'];
      function accessoryCtrl($scope,$location,$http,$rootScope,API_URL) {

        //Addin record
          var vm = $scope;
           vm.copier = {};
           vm.accessory = {};
          vm.accessoryError = "";

          //get product details
          $http.get(API_URL + 'copiers')
          .success(function (response,data) {
           //console.log(response.copiers);
          $scope.copiers = response.copiers;
          }).error(function (response) {
            alert('Not responding');
          });

         //get accessories
         $http.get(API_URL + 'accessories')
         .success(function (response,data) {
          //console.log(response);
         $scope.accessories = response.accessories;
         }).error(function (response) {
           alert('Not responding');
         });

         //below function is used for refresh the page or to reload ,we can call it at submit button of accessory modal
         vm.getAccessory = function() {
          $http.get(API_URL + 'accessories')
          .success(function (response,data) {
           //console.log(response);
          $scope.accessories = response.accessories;
          }).error(function (response) {
            alert('Not responding');
          });
         }


         $scope.clickAccessory = function(id,idd){
           var element = document.getElementById(id);
           var element1 = document.getElementById(id);
           console.log("element ::" + JSON.stringify(element));
            //$('#id').collapse('show');
            this.e1 = $(element);

                if(this.e1.hasClass('hide')){
                  console.log('hide class');
                  element.className = 'show';
                }
                $scope.hideNow = function(){
                if(this.e1.hasClass('show')){
                  console.log('show class');
                  element.className = 'hide';
                }
              }


//            $(document).ready(function(){
//     $("#flip").click(function(){
//         $("#panel").slideToggle("slow");
//     });
// });
          //element1.className = 'hide';

           $scope.showCopier = false;
           $http.post(API_URL + 'get-copier-accessories/' + id)
           .success(function (response) {
            console.log(response.copiers1);
           $scope.copiers1 = response.copiers1;
 $scope.showCopier = true;
           }).error(function (response) {
             alert('Not responding');
           });

         }

         //toggle function
         $scope.toggle = function(accessory) {
           console.log(accessory);
          // console.log(JSON.stringify(category));
          $scope.editaccessories = accessory;
          $('#myModal2').modal('show');
         }

        $scope.editAccessory = function(response,id) {
          $scope.accessories= response;
          //console.log(response);
          $http({
                     method: 'POST',
                     url: API_URL + 'accessories/'+ id,
                     data: $.param($scope.accessories),
                     headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                 }).success(function(response) {
                     //console.log(response);
                     vm.getAccessory();
                 }).error(function(response) {
                     console.log(response);
                     alert('This is embarassing. An error has occured. Please check the log for details');
                 });
               }

               $scope.disableAccessory = function(id) {
                 $http.post(API_URL + 'delete-accessories/' + id)
                 .success(function (response,data) {
                   // alert('Delete successfully');
                      vm.getAccessory();
                 }).error(function (response) {
                   alert('Not responding');
                 });
                }

          //adding accessories
          $scope.addAccessory = function() {
            //  console.log(vm.accessory);
        //  $scope.accessory.copiers = $scope.copiers.map(function(item) { return item.id; });
        console.log($scope.accessory.copiers);
      //  console.log($scope.accessory);

              $http({

                  headers:{
                      'content-Type': 'application/json'
                  },
                  url: API_URL + 'add-accessories',      //baseUrl defined in index page
                  method: "POST",
                  data: {
                      accessory_name:$scope.accessory.accessory_name,
                      price:$scope.accessory.price,
                      copier_id:$scope.accessory.copiers,

                  }
              }).success(function(response){
                console.log(response);
                if(response.exists != "exist"){
                    vm.getAccessory();
                }
                else{
                  alert('Accessory already present');
                }
              }).error(function(data,status,headers){
                  console.log(data,status,headers);
                  alert(data);
              });
                  }

        }
//end of accessories

        categoryCtrl.$inject = ['$scope','$location','$http','$rootScope','API_URL'];
        function categoryCtrl($scope,$location,$http,$rootScope,API_URL) {

          //Addin record
            var vm = $scope;
             vm.copier = {};
            vm.accessoryError = "";

           //get accessories
           $http.get(API_URL + 'categories')
           .success(function (response,data) {
            //console.log(response);
           $scope.categories = response.categories;
           }).error(function (response) {
             alert('Not responding');
           });

           //below function call for refresh the category page
           vm.getCategory = function() {
            $http.get(API_URL + 'categories')
            .success(function (response,data) {
             //console.log(response);
            $scope.categories = response.categories;
            }).error(function (response) {
              alert('Not responding');
            });
           }

           $scope.toggle = function(category) {
            // console.log(category);
            // console.log(JSON.stringify(category));
            $scope.editCategories = category;
            $('#myModal2').modal('show');
           }

           $scope.editCategory = function(id,category_name) {
           console.log(id,category_name);
            $http.post(API_URL + 'categories/' + id +"/" + category_name)
            .success(function (response,data) {
              // alert('edit successfully');
                 vm.getCategory();
            }).error(function (response) {
              alert('Not responding');
            });
           }

           $scope.disableCategory = function(id) {
           console.log(id);
           if (confirm("Are you sure you want to delete?") == true) {
            $http.post(API_URL + 'delete-categories/' + id)
            .success(function (response,data) {
              // alert('Delete successfully');
                 vm.getCategory();
            }).error(function (response) {
              alert('Not responding');
            });
          }
        }

          //adding accessories
          $scope.addCategory = function() {
           //console.log(vm.copier);

          $http({

            headers:{
            'content-Type': 'application/json'
            },
            url: API_URL + 'add-categories',      //baseUrl defined in index page
            method: "POST",
            data: {
            category_name:$scope.copier.category_name,
            }
            }).success(function(response){
              console.log(response.exists);
              if(response.exists != "exist"){
                  vm.getCategory();
              }
              else{
                alert('Category already present');
              }

              }).error(function(data,status,headers){
              console.log(data,status,headers);
                alert(data);
                });
              }

          }


//lease payment controller
paymentCtrl.$inject = ['$scope','$location','$http','$rootScope','API_URL'];
function paymentCtrl($scope,$location,$http,$rootScope,API_URL) {

  //Addin record
    var vm = $scope;
     vm.copier = {};
    vm.accessoryError = "";

    $http.get(API_URL + 'copiers')
    .success(function (response,data) {
     //console.log(response);
    $scope.copiers = response.copiers;
    }).error(function (response) {
      alert('Not responding');
    });

   //get payment-options
   $http.get(API_URL + 'payment-options')
   .success(function (response,data) {
    //console.log(response);
   $scope.payments = response.payments;
   }).error(function (response) {
     alert('Not responding');
   });

   //below function is used for refresh the page or to reload ,we can call it at submit button of accessory modal
   vm.getPayment = function() {
    $http.get(API_URL + 'payment-options')
    .success(function (response,data) {
     //console.log(response);
    $scope.payments = response.payments;
    }).error(function (response) {
      alert('Not responding');
    });
   }

   //toggle function
   $scope.toggle = function(payment) {
     console.log(payment.copier_id);
    // console.log(JSON.stringify(category));
    $scope.editpayments = payment;
    $('#myModal2').modal('show');
   }

           $scope.editPayment = function(response,id) {
             $scope.payments= response;
             console.log(response);
             $http({
                        method: 'POST',
                        url: API_URL + 'payments/'+ id,
                        data: $.param($scope.payments),
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                    }).success(function(response) {
                      console.log(response);

                    }).error(function(response) {
                        console.log(response);
                        alert('This is embarassing. An error has occured. Please check the log for details');
                    });

                   }

                   $scope.disablePayment = function(id) {
                   console.log(id);
                    $http.post(API_URL + 'delete-payments/' + id)
                    .success(function (response,data) {
                      // alert('Delete successfully');
                         vm.getPayment();
                    }).error(function (response) {
                      alert('Not responding');
                    });
                   }

    //adding lease payments
    $scope.addPayment = function() {
      //  console.log(vm.copier);

        $http({

            headers:{
                'content-Type': 'application/json'
            },
            url: API_URL + 'add-payments',      //baseUrl defined in index page
            method: "POST",
            data: {
                id:$scope.copier.id,
                no_of_months:$scope.copier.no_of_months,
                price_per_month:$scope.copier.price_per_month,
                support_price:$scope.copier.support_price,
                delivery_price:$scope.copier.delivery_price,
                pickup_price:$scope.copier.pickup_price,

            }
        }).success(function(response){
            console.log(response);
            if(response.exists != "exist"){
                vm.getPayment();
            }
            else{
              alert('Payment plan for copier already present');
            }

        }).error(function(data,status,headers){
            console.log(data,status,headers);
            alert(data);
        });
            }
  }
//end of lease payment


//crystalBall service controller start

      CrystalballServiceCtrl.$inject = ['$scope','$location','$http','$rootScope','API_URL'];
      function CrystalballServiceCtrl($scope,$location,$http,$rootScope,API_URL) {

        //Addin record
          var vm = $scope;
           vm.copier = {};
           vm.accessory = {};
          vm.accessoryError = "";

          //below copier details will be used in model when add service
          $http.get(API_URL + 'copiers')
          .success(function (response,data) {
           //console.log(response);
          $scope.copiers = response.copiers;
          }).error(function (response) {
            alert('Not responding');
          });

         //get accessories
         $http.get(API_URL + 'crystalballservice')
         .success(function (response,data) {
          //console.log(response);
         $scope.crystalballservices = response.crystalballservices;
         }).error(function (response) {
           alert('Not responding');
         });

         //below function is used for refresh the page or to reload ,we can call it at submit button of accessory modal
         vm.getCrystalballService = function() {
          $http.get(API_URL + 'crystalballservice')
          .success(function (response,data) {
           //console.log(response.crystalballservices);
          $scope.crystalballservices = response.crystalballservices;
          }).error(function (response) {
            alert('Not responding');
          });
         }

         //toggle function
         $scope.toggle = function(service) {
           console.log(service.copier_id);
          // console.log(JSON.stringify(category));
          $scope.editservices = service;
          $('#myModal2').modal('show');
         }

        $scope.editCrystalballService = function(response,id) {
          $scope.crystalballservices = response;
          //console.log(response);
          $http({
                     method: 'POST',
                     url: API_URL + 'crystalballservice/'+ id,
                     data: $.param($scope.crystalballservices),
                     headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                 }).success(function(response) {
                     //console.log(response);
                     alert("Successfully done!!");
                     vm.getCrystalballService();
                 }).error(function(response) {
                     console.log(response);
                     alert('This is embarassing. An error has occured. Please check the log for details');
                 });
               }

               $scope.disableCrystalballService = function(id) {
                 $http.post(API_URL + 'delete-crystalballservice/' + id)
                 .success(function (response,data) {
                   // alert('Delete successfully');
                    vm.getCrystalballService();
                 }).error(function (response) {
                   alert('Not responding');
                 });
                }

          //adding accessories
          $scope.addCrystalballService = function() {
            //  console.log(vm.accessory);
        //  $scope.accessory.copiers = $scope.copiers.map(function(item) { return item.id; });
        console.log($scope.service);
      //  console.log($scope.accessory);

              $http({

                  headers:{
                      'content-Type': 'application/json'
                  },
                  url: API_URL + 'add-crystalballservice',      //baseUrl defined in index page
                  method: "POST",
                  data: {
                      service_name:$scope.service.service_name,
                      copier_id:$scope.service.copiers,

                  }
              }).success(function(response){
                  console.log(response);
                  if(response.exists != "exist"){
                      vm.getCrystalballService();
                  }
                  else{
                    alert('Service for copier already present');
                  }

              }).error(function(data,status,headers){
                  console.log(data,status,headers);
                  alert(data);
              });
                  }

        }

//crystalBall service end



//crystalBall policy controller start

      crystalballPolicyCtrl.$inject = ['$scope','$location','$http','$rootScope','API_URL'];
      function crystalballPolicyCtrl($scope,$location,$http,$rootScope,API_URL) {

        //Addin record
          var vm = $scope;
           vm.copier = {};
           vm.policy = {};
          vm.accessoryError = "";

          //below copier details will be used in model when add service
          $http.get(API_URL + 'copiers')
          .success(function (response,data) {
           //console.log(response);
          $scope.copiers = response.copiers;
          }).error(function (response) {
            alert('Not responding');
          });

         //get policy
         $http.get(API_URL + 'crystalballpolicy')
         .success(function (response) {
        //  console.log(response);
         $scope.crystalballpolicy = response.crystalballpolicy;
       }).error(function (error) {
           alert('Not responding');
         });

         //below function is used for refresh the page or to reload ,we can call it at submit button of accessory modal
         vm.getCrystalballPolicy = function() {
          $http.get(API_URL + 'crystalballpolicy')
          .success(function (response) {
           //console.log(response.crystalballservices);
          $scope.crystalballpolicy = response.crystalballpolicy;
          }).error(function (response) {
            alert('Not responding');
          });
         }

         //toggle function
         $scope.toggle = function(policy) {
           //console.log(policy);
          // console.log(JSON.stringify(category));
          $scope.editpolicy = policy;
          $('#myModal2').modal('show');
         }

        $scope.editPolicy = function(response,id) {
          $scope.crystalballpolicy = response;
          console.log(response,id);
          $http({
                     method: 'POST',
                     url: API_URL + 'crystalballpolicy/'+ id,
                     data: $.param($scope.crystalballpolicy),
                     headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                 }).success(function(response) {
                     //console.log(response);
                      vm.getCrystalballPolicy();
                 }).error(function(response) {
                     console.log(response);
                     alert('This is embarassing. An error has occured. Please check the log for details');
                 });
               }

               $scope.disablePolicy = function(id) {
                 $http.post(API_URL + 'delete-crystalballpolicy/' + id)
                 .success(function (response,data) {
                   // alert('Delete successfully');
                    vm.getCrystalballPolicy();
                 }).error(function (response) {
                   alert('Not responding');
                 });
                }

          //adding policy
          $scope.addPolicy = function() {
              $http({
                  headers:{
                      'content-Type': 'application/json'
                  },
                  url: API_URL + 'add-crystalballpolicy',      //baseUrl defined in index page
                  method: "POST",
                  data: {
                      policy_description:$scope.policy.policy_description,
                  }
              }).success(function(response){
                  console.log(response);
                vm.getCrystalballPolicy();

              }).error(function(data,status,headers){
                  console.log(data,status,headers);
                  alert(data);
              });
                  }

        }

//crystalBall policy end


      userCtrl.$inject = ['$scope','$location','$http','$rootScope','API_URL'];
      function userCtrl($scope,$location,$http,$rootScope,API_URL) {

        //Addin record
          var vm = $scope;
           vm.user = {};
          vm.registerError = "";

          $scope.submitOrder = function(response) {
            //console.log(response);
            //console.log($scope.user);
            //console.log($scope.user.summaries);
            //console.log($scope.user.summaries.accessories);
            $scope.user.summaries = JSON.parse(sessionStorage.getItem("summary"));
            $scope.list = [];
              //finding the particular id from an object and push,make a separate array
            angular.forEach($scope.user.summaries.accessories, function(value) {
              $scope.list.push(value.id);
            });
          //  console.log($scope.list);

            $http({

                headers:{
                    'content-Type': 'application/json'
                },
                url: API_URL + 'userdetails',      //baseUrl defined in index page
                method: "POST",
                data: {
                    email:$scope.user.email,
                    password:$scope.user.password,
                    first_name:$scope.user.first_name,
                    last_name:$scope.user.last_name,
                    phone_no:$scope.user.phone_no,
                    company_name:$scope.user.company_name,
                    address:$scope.user.address,
                    city:$scope.user.city,
                    state:$scope.user.state,
                    zipcode:$scope.user.zipcode,
                    delivery_date:$scope.user.delivery_date,
                    delivery_time:$scope.user.delivery_time,
                    copier_id:$scope.user.summaries.copiers.id,
                    payment_id:$scope.user.summaries.payments.id,
                    accessory_id:$scope.list,
                  }
            }).success(function(response){
                console.log(response);
                $location.path('/thanks');
            }).error(function(data,status,headers){
                console.log(data,status,headers);
                alert(data);
            });
                }
        }



    logoutCtrl.$inject = ['$scope','$location','$http','$rootScope','API_URL'];
    function logoutCtrl($scope,$location,$http,$rootScope,API_URL) {

         // here first logout function call the api and return response from the backend and then it redirect to logout page url
console.log('hello');
            $http.get(API_URL + 'logout')
                .success(function (response) {
                    console.log(JSON.stringify(response));
                    $location.path("/login");
                }).error(function (response) {
                   alert('not logout');
                });

    }



    productCtrl.$inject = ['$scope','$location','$http','$rootScope','API_URL'];
    function productCtrl($scope,$location,$http,$rootScope,API_URL) {

        // here first logout function call the api and return response from the backend and then it redirect to logout page url
        $http.get(API_URL + 'copiers')
            .success(function (response,data) {
             //console.log(JSON.stringify(response));
                //console.log(response);
                $scope.copiers = response.copiers;
              //  sessionStorage.setItem("emp-key", JSON.stringify(response)); //this is for setting the session
                //console.log(sessionStorage.getItem("emp-key")); // this will be used for getting session
            }).error(function (response) {
            alert('Not responding');
        });

        } //closed productCtrl

        GetAllProductInfoCtrl.$inject = ['$scope','$location','$http','$rootScope','$stateParams','API_URL'];
        function GetAllProductInfoCtrl($scope,$location,$http,$rootScope,$stateParams,API_URL) {
          var id = $stateParams.id;
           $http.get(API_URL + 'pull-copier-details/' + id)
               .success(function (response) {
                   $scope.copiers = response.copiers[0];
                   $scope.accessories = response.accessories;
                   $scope.payments = response.payments;
                   $scope.user = {};
                   $scope.user.copiers = response.copiers[0];
        }).error(function (err) {
                 alert('Not responding');
               });

           $scope.summary = function(response) {
           sessionStorage.setItem("summary", JSON.stringify(response));
           $location.path('/summary');
                  }
          }

summaryCtrl.$inject = ['$scope','$location','$http','$rootScope','API_URL'];
    function summaryCtrl($scope,$location,$http,$rootScope,API_URL) {
    //  console.log("summary page :: " + sessionStorage.getItem("summary"));
     $scope.summaries = JSON.parse(sessionStorage.getItem("summary"));
    //  console.log($scope.summaries);
      var copier_id = $scope.summaries.copiers.id;
      $http.get(API_URL + "getcrystalballservices/" + copier_id)
          .success(function(response) {
              $scope.crystalballservices1 = response.crystalballservices1;
              //console.log($scope.crystalballservices1);


          });

          $http.get(API_URL + "crystalballpolicy")
              .success(function(response) {
                  $scope.crystalballpolicy = response.crystalballpolicy;
                  //console.log($scope.crystalballpolicy);
              });
           }


orderHistoryCtrl.$inject = ['$scope','$location','$http','$rootScope','API_URL'];
    function orderHistoryCtrl($scope,$location,$http,$rootScope,API_URL) {
    //  console.log("summary page :: " + sessionStorage.getItem("summary"));
    console.log(JSON.parse(sessionStorage.getItem("userId")));
        var login_user_id = JSON.parse(sessionStorage.getItem("userId"));
      $scope.orderhistory={};
      $http.get(API_URL + "orderhistory/" + login_user_id)
          .success(function(response) {
              $scope.orderhistory = response.orderhistory;
              console.log(response);

          });

          $http.get(API_URL + "crystalballpolicy")
              .success(function(response) {
                  $scope.crystalballpolicy = response.crystalballpolicy;
                  //console.log($scope.crystalballpolicy);
              });
           }


mainCtrl.$inject = ['$scope','$location','$http','$rootScope','API_URL'];
    function mainCtrl($scope,$location,$http,$rootScope,API_URL) {

        //console.log(API_URL);
        //retrieve employees listing from API
        $http.get(API_URL + "customers")
            .success(function(response) {
                $scope.customers = response;
            });



        // //show modal form
        // $scope.toggle = function(modalstate, id) {
        //     $scope.modalstate = modalstate;
        //
        //     switch (modalstate) {
        //         case 'add':
        //             $scope.form_title = "Add New Employee";
        //             break;
        //         case 'edit':
        //             $scope.form_title = "Employee Detail";
        //             $scope.id = id;
        //             $http.get(API_URL + 'employees/' + id)
        //                 .success(function(response) {
        //                     console.log(response);
        //                     $scope.employee = response;
        //                 });
        //             break;
        //         default:
        //             break;
        //     }
        //     console.log(id);
        //     $('#myModal').modal('show');
        // }
        //
        // //save new record / update existing record
        // $scope.save = function(modalstate, id) {
        //     var url = API_URL + "employees";
        //
        //     //append employee id to the URL if the form is in edit mode
        //     if (modalstate === 'edit'){
        //         url += "/" + id;
        //     }
        //
        //     $http({
        //         method: 'POST',
        //         url: url,
        //         data: $.param($scope.employee),
        //         headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        //     }).success(function(response) {
        //         console.log(response);
        //         location.reload();
        //     }).error(function(response) {
        //         console.log(response);
        //         alert('This is embarassing. An error has occured. Please check the log for details');
        //     });
        // }
        //
        // //delete record
        // $scope.confirmDelete = function(id) {
        //     var isConfirmDelete = confirm('Are you sure you want to delete this record?');
        //
        //     if (isConfirmDelete) {
        //         $http({
        //             method: 'DELETE',
        //             url: API_URL + 'employees/' + id
        //         }).
        //         success(function(data) {
        //             console.log(data);
        //             location.reload();
        //         }).
        //         error(function(data) {
        //             console.log(data);
        //             alert('Unable to delete');
        //         });
        //     } else {
        //         return false;
        //     }
        // }

    };


    })();
