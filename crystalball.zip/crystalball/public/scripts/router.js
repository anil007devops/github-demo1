(function (){

'use strict';

angular
.module('App')
.config(config);

config.$inject = ['$stateProvider','$urlRouterProvider'];
function config ($stateProvider,$urlRouterProvider){


  $urlRouterProvider
      .otherwise('/');

  $stateProvider

      .state('login',{
        url:'/login',
        templateUrl:'partials/login.php',
        controller:'LoginController',

      })

      .state('signup',{
        url:'/signup',
        templateUrl:'partials/signup.php',
        controller:'SignupController',

      })

      .state('/',{
        url:'/',
        templateUrl:'partials/home.php',
        controller:'',

      })

      .state('/about',{
        url:'/about',
        templateUrl:'partials/about.php',
        controller:'MainController',

      })

      .state('/blog',{
        url:'/blog',
        templateUrl:'partials/blog.php',
        controller:'',

      })
      .state('/contact',{
        url:'/contact',
        templateUrl:'partials/contact.php',
        controller:'',

      })

      .state('/logout',{
          url:'/logout',
          templateUrl:'partials/login.php',
          controller:'LogoutController',

      })

      .state('/copiers',{
          url:'/copiers',
          templateUrl:'partials/product.php',
          controller:'ProductController',

      })

      .state('/pull-details',{
          url:'/pull-details/:id',
          templateUrl:'partials/pull-details.php',
          controller:'GetAllProductInfoController',

      })

      .state('/userdetails',{
          url:'/userdetails',
          templateUrl:'partials/userdetails.php',
          controller:'UserController',

      })

      .state('add-copiers',{
        url:'/add-copiers',
        templateUrl:'partials/add-copier.php',
        controller:'CopierController',

      })

      .state('add-accessories',{
        url:'/add-accessories',
        templateUrl:'partials/add-accessory.php',
        controller:'AccessoryController',

      })

      .state('add-categories',{
        url:'/add-categories',
        templateUrl:'partials/add-category.php',
        controller:'CategoryController',

      })

      .state('add-payments',{
        url:'/add-payments',
        templateUrl:'partials/add-payment.php',
        controller:'PaymentController',
      })

      .state('add-crystalball-service',{
        url:'/add-crystalball-service',
        templateUrl:'partials/crystalball-service.php',
        controller:'CrystalballServiceController',
      })

      .state('add-pricing-policy',{
        url:'/add-pricing-policy',
        templateUrl:'partials/policy.php',
        controller:'CrystalballPolicyController',
      })

      .state('summary',{
          url:'/summary',
          templateUrl:'partials/summary.php',
          controller:'SummaryController',

      })

      .state('/admin-dashboard',{
          url:'/admin-dashboard',
          templateUrl:'partials/admin-dashboard.php',
          controller:'CopierController',

      })

      .state('/user-dashboard',{
          url:'/user-dashboard',
          templateUrl:'partials/user-dashboard.php',
          controller:'ProductController',

      })

      .state('/thanks',{
          url:'/thanks',
          templateUrl:'partials/thanks.php',
          controller:'',

      })

      .state('/orderhistory',{
          url:'/orderhistory',
          templateUrl:'partials/orderhistory.php',
          controller:'OrderHistoryController',

      })

}

})();
