<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaymentOption extends Model
{
  protected $fillable = [
      'no_of_months','price_per_month', 'support_price', 'delivery_price','pickup_price',
  ];
}
