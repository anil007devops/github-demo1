<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Copier extends Model
{

    protected $fillable = [
        'copier_model', 'print_page_per_minute', 'monthly_pages','monthly_price',
        'price_color_page','price_bw_page','used_by','plan',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */

}
