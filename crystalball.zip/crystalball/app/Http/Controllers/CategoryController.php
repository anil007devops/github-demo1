<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use App\Category;
use App\Status;
use DB;
class CategoryController extends Controller
{
  public function getCategory($id=null){

    if ($id == null) {
     $categories = Category::where('categories.status_id','=','1')->orderBy('id','asc')->get();
      // $categories = DB::table('categories')
      //         ->join('actions','categories.id','=','actions.category_id')
      //         ->select('categories.id','categories.category_name')
      //         ->where('actions.action','=','enable')
      //         ->orderBy('categories.id','asc')->get();
      return Response::json(['categories' => $categories]);
    }
    else{
      return $this->show($id);
    }

  }


  public function storeCategoryDetails(Request $request){
//  $category = DB::select('select category_name from categories');
    $err = "exist";
    $category = Category::where('category_name','=',$request['category_name'])->first();
    if($category === null){
    $category1 = new Category;
    $category1->category_name = $request['category_name'];
    $category1->save();
    return response('Category record added successfully created with id ' . $category1);
  }
else{
return Response::json(['exists' => $err]);
}
}

public function editCategory (Request $request,$id,$category_name){
$category = Category::find($id);
$category->category_name = $category_name;
$category->save();
return "success updating" .$category->id;
  }


  public function disableCategory (Request $request,$id){
  $category = Category::find($id);
  $category->status_id = "2";
  $category->save();
  return "success updating" .$category->id;
    }

}
