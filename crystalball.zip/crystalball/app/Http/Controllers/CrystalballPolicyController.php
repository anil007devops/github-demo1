<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\CrystalballPolicy;
use DB;
use Illuminate\Support\Facades\Response;

class CrystalballPolicyController extends Controller
{
  public function getPolicy($id=null){

    if ($id == null) {
     $crystalballpolicy = CrystalballPolicy::where('crystalball_policies.status_id','=','1')->orderBy('id','asc')->get();
      // $categories = DB::table('categories')
      //         ->join('actions','categories.id','=','actions.category_id')
      //         ->select('categories.id','categories.category_name')
      //         ->where('actions.action','=','enable')
      //         ->orderBy('categories.id','asc')->get();
      return Response::json(['crystalballpolicy' => $crystalballpolicy]);
    }
    else{
      return $this->show($id);
    }

  }


  public function storePolicyDetails(Request $request){
//  $category = DB::select('select category_name from categories');
    $err = "exist";
    $policy = CrystalballPolicy::where('policy_description','=',$request['policy_description'])->first();
    if($policy === null){
    $policy1 = new CrystalballPolicy;
    $policy1->policy_description = $request['policy_description'];
    $policy1->save();
    return response('Policy record added successfully created with id ' . $policy1);
  }
else{
return Response::json(['exists' => $err]);
}
}

public function editPolicy (Request $request,$id){
$policy = CrystalballPolicy::find($id);
$policy->policy_description = $request['policy_description'];
$policy->save();
return "success updating" .$policy->id;
  }


  public function disablePolicy(Request $request,$id){
  $policy = CrystalballPolicy::find($id);
  $policy->status_id = "2";
  $policy->save();
  return "success updating" .$policy->id;
    }

}
