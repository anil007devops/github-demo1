<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Copier;
use App\Accessories;
use App\Category;
use App\PaymentOption;
use App\Order;
use Illuminate\Support\Facades\Response;
use DB;
class OrderHistoryController extends Controller
{
    public function getOrderHistory(Request $request,$id){
       $orderhistory = DB::table('orders')
                     ->join('copiers','copiers.id','=','orders.copier_id')
                     ->join('payment_options','payment_options.id','=','orders.payment_id')
                     //->join('order_accessories','order_accessories.order_id','=','orders.id')
                      //->join('accessories','accessories.id','=','order_accessories.accessory_id')
                      ->join('categories','categories.id','=','copiers.category_id')
                     ->select('copiers.*','payment_options.*','categories.category_name','orders.id as o_id','orders.order_date','orders.delivery_date','orders.delivery_time')
                     ->where('orders.user_id','=',$id)
                     ->get();
foreach($orderhistory as $history){
$accessories = DB::table('orders')
              ->join('order_accessories','order_accessories.order_id','=','orders.id')
              ->join('accessories','accessories.id','order_accessories.accessory_id')
              ->select('accessories.*')
              ->where('orders.id','=',$history->o_id)->get();

     }
      return Response::json(['orderhistory' => $orderhistory,'$accessories'=>$accessories]);
  }

}
