<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use App\Copier;
use App\Category;
use App\Accessories;
use App\PaymentOption;
use DB;
class SummaryController extends Controller
{
  public function getSummary(Request $request,$cop_id){
    $copiers = DB::table('copiers')
            ->join('categories','copiers.category_id','=','categories.id')
            // ->join('payment_options','payment_options.copier_id','=','copiers.id')
            ->select('copiers.*','categories.category_name')
            ->where('copiers.id','=',$cop_id)->get();

$pay_id = $request['payment_id'];
$acc_id = $request['accessory_id'];
//$acc_id = $acc_id['acc_id'];
  $payments = DB::table('payment_options')
            ->join('copiers','copiers.id','=','payment_options.copier_id')
            ->where('payment_options.id','=',$pay_id)->get();

    $accessories = Accessories::where('accessories.id','=',$acc_id);

    // return Response::json(['id'=>$id,'id2'=>$id2,'id3'=>$id3],202);
   return Response::json(array('accessories'=>$accessories), 202);
  }

}
