<?php

namespace App\Http\Controllers;
use App\Copier;
use App\Accessories;
use App\Category;
use App\PaymentOption;
use App\CopierDetails;
use App\CopierAccessory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use DB;
class CopierController extends Controller
{
    public function getIndex($id = null) {     //this return copier info
        if ($id == null) {
// $copiers = Copier::where('status_id','=','1')->orderBy('copiers.id','asc')->get();
$copiers = DB::table('copiers')
        ->join('categories','copiers.category_id','=','categories.id')
        ->select('copiers.*','categories.category_name')
        ->orderBy('copiers.id','asc')->get();
return Response::json(['copiers' => $copiers],202);
}
else {
    return $this->show($id);
}
}

public function getAll(Request $request,$id){
  $copiers = DB::table('copiers')
          ->join('categories','copiers.category_id','=','categories.id')
          ->join('payment_options','payment_options.copier_id','=','copiers.id')
          ->select('copiers.*','categories.category_name')
          ->where('copiers.id','=',$id)->get();
          // ->orderBy('copiers.id','asc')
$payments = DB::table('copiers')
          ->join('payment_options','payment_options.copier_id','=','copiers.id')
          ->where('copiers.id','=',$id)->get();

  $accessories = DB::table('accessories')
               ->join('copier_accessories','accessories.id','=','copier_accessories.accessory_id')
               ->join('copiers','copiers.id','copier_accessories.copier_id')
               ->select('accessories.id','accessories.accessory_name','accessories.price')
               ->where('copiers.id','=',$id)
               ->where('accessories.status_id','=','1')->get();

return Response::json(['copiers' => $copiers,'accessories'=>$accessories,'payments'=>$payments], 202);
}

public function storeCopierDetails(Request $request){
  $err = "exist";
  $copier = Copier::where('copier_model','=',$request['copier_model'])->first();
  if($copier === null){
  $copier = new Copier;
  $copier->category_id = $request['id'];
  $copier->copier_model = $request['copier_model'];
  $copier->print_page_per_minute = $request['print_page_per_minute'];
  $copier->monthly_pages = $request['monthly_pages'];
  $copier->monthly_price = $request['monthly_price'];
  $copier->price_color_page = $request['price_color_page'];
  $copier->price_bw_page = $request['price_bw_page'];
  $copier->used_by = $request['used_by'];
  $copier->save();
  return response('Product record added successfully created with id ' . $copier->id);
}
else{
return Response::json(['exists' => $err]);
}
  }

public function editCopiers(Request $request,$id){
  $copier = Copier::find($id);
  $copier->copier_model = $request['copier_model'];
  $copier->monthly_pages = $request['monthly_pages'];
  $copier->print_page_per_minute = $request['print_page_per_minute'];
  $copier->price_color_page = $request['price_color_page'];
  $copier->price_bw_page = $request['price_bw_page'];
  $copier->monthly_price = $request['monthly_price'];
  $copier->used_by = $request['used_by'];
  //$copier->category_id = $request['idd'];
  $copier->save();
  return "success updating" .$copier->id;
}

public function disableCopiers(Request $request,$id){
$copier = Copier::find($id);
$copier->status_id = "2";
$copier->save();
return "success updating" .$copier->id;
  }


}
