<?php

namespace App\Http\Controllers;
use App\Accessories;
use App\CopierDetails;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use App\CopierAccessory;
use DB;
class AccessoryController extends Controller
{
    public function getAccessory($id=null){

      if ($id == null) {
        $accessories = Accessories::where('status_id','=','1')->orderBy('id','asc')->get();
        return Response::json(['accessories' => $accessories]);
      }
      else{
        return $this->show($id);
      }

    }

public function getCopierAccessoryById (Request $request,$id){
$cop = DB::table('accessories')
     ->join('copier_accessories','accessories.id','=','copier_accessories.accessory_id')
     ->join('copiers','copier_accessories.copier_id','=','copiers.id')
     ->select('copiers.copier_model')
     ->where('accessories.id','=',$id)->get();
return Response::json(['copiers1' => $cop],202);
  }

    public function editAccessory (Request $request,$id){
     $accessory = Accessories::find($id);
     $accessory->delete();
    // $db = DB::table('accessories')
    //     ->join('copier_accessories','copier_accessories.accessory_id','=','accessories.id')
    //     ->where('accessories.id','=',$id)->get();
    //     $db->delete();
    $accessory = new Accessories;
    $accessory->accessory_name = $request['accessory_name'];
    $accessory->price = $request['price'];
    $accessory->save();

    $last_accessory_id = $accessory->id;
    $order_acc= $request['copiers'];
    foreach($order_acc as $value)
    {
      $copier_acc = new CopierAccessory;
      $copier_acc->copier_id = $value;
      $copier_acc->accessory_id = $last_accessory_id;
      $copier_acc->save();

    }
    return "success updating" .$accessory->id;
  }


      public function disableAccessory (Request $request,$id){
      $accessory = Accessories::find($id);
      $accessory->status_id = "2";
      $accessory->save();
      return "success updating" .$accessory->id;
        }

    public function storeAccessoryDetails(Request $request){
    $err = "exist";
    $accessory = Accessories::where('accessory_name','=',$request['accessory_name'])->first();
    if($accessory === null){
    $accessory = new Accessories;
    $accessory->accessory_name = $request['accessory_name'];
    $accessory->price = $request['price'];
    $accessory->save();

    $last_accessory_id = $accessory->id;
    $order_acc= $request['copier_id'];

    foreach($order_acc as $value)
    {
      $copier_acc = new CopierAccessory;
      $copier_acc->copier_id = $value;
      $copier_acc->accessory_id = $last_accessory_id;
      $copier_acc->save();

    }
return Response::json(['accessories' => $copier_acc]);
    }
    else{
    return Response::json(['exists' => $err]);
    }
  }

} //closed class
