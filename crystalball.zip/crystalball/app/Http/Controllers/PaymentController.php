<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use App\PaymentOption;
use App\Copier;
use DB;
class PaymentController extends Controller
{

  public function getPayment($id=null){

    if ($id == null) {
      // $payments = PaymentOption::orderBy('id','asc')->get();

      $payments = DB::table('payment_options')
              ->join('copiers','copiers.id','=','payment_options.copier_id')
              ->join('categories','categories.id','=','copiers.category_id')
              ->select('payment_options.*','copiers.copier_model','categories.category_name')
              ->where('payment_options.status_id','=','1')
              ->orderBy('copiers.id','asc','payment_options.no_of_months','dsc')->get();
      // return $copier->toJson();
      return Response::json(['payments' => $payments]);
    }
    else{
      return $this->show($id);
    }

  }

    public function storePaymentDetails(Request $request){
    $err = "exist";
    $copier = PaymentOption::select('no_of_months')
             ->where('copier_id','=',$request['id'])->first();

    if($copier === null){
    $payment = new PaymentOption;
    $payment->copier_id = $request['id'];
    $payment->no_of_months = $request['no_of_months'];
    $payment->price_per_month = $request['price_per_month'];
    $payment->support_price = $request['support_price'];
    $payment->delivery_price = $request['delivery_price'];
    $payment->pickup_price = $request['pickup_price'];

    $payment->save();


    return response('Payment record added successfully created with id ' . $payment->id);
  }
  else{
  return Response::json(['exists' => $err]);
  }
}

  public function editPayment(Request $request,$id){
  $payment = PaymentOption::find($id);
  //$payment->no_of_months = $request['no_of_months'];
  $payment->price_per_month = $request['price_per_month'];
  $payment->support_price = $request['support_price'];
  $payment->delivery_price = $request['delivery_price'];
  $payment->pickup_price = $request['pickup_price'];
  $payment->save();
  return "success updating" .$payment->id;
    }



    public function disablePayment(Request $request,$id){
    $payment = PaymentOption::find($id);
    $payment->status_id = "2";
    $payment->save();
    return "success updating" .$payment->id;
      }

}
