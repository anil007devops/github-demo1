<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use App\CrystalballService;
use App\ServiceAll;
use App\Status;
use DB;

class CrystalballServiceController extends Controller
{

  public function getCrystalballService($id=null){

    if ($id == null) {

      $crystalballservices = DB::table('crystalball_services')
              ->join('service_alls','service_alls.service_id','=','crystalball_services.id')
              ->join('copiers','copiers.id','=','service_alls.copier_id')
              ->select('crystalball_services.*','copiers.copier_model','copiers.id as copier_id')
              ->where('crystalball_services.status_id','=','1')
              ->orderBy('copiers.id','asc')->get();
      // return $copier->toJson();
      return Response::json(['crystalballservices' => $crystalballservices]);
    }
    else{
      return $this->show($id);
    }

  }

public function getCrystalballServiceforsummary(Request $request,$copier_id){

    $crystalballservices = DB::table('crystalball_services')
            ->join('service_alls','service_alls.service_id','=','crystalball_services.id')
            ->join('copiers','copiers.id','=','service_alls.copier_id')
            ->select('crystalball_services.*')
            ->where('crystalball_services.status_id','=','1')
            ->where('service_alls.copier_id','=',$copier_id)
            ->orderBy('copiers.id','asc')->get();
    // return $copier->toJson();
    return Response::json(['crystalballservices1' => $crystalballservices],202);
  }


public function editCrystalballService(Request $request,$id){
$service = CrystalballService::find($id);
$service->delete();

$service = new CrystalballService;
$service->service_name = $request['service_name'];
$service->save();

$last_service_id = $service->id;
$order_acc= $request['copiers'];
foreach($order_acc as $value)
{
  $copier_acc = new ServiceAll;
  $copier_acc->copier_id = $value;
  $copier_acc->service_id = $last_service_id;
  $copier_acc->save();

  }
return "success updating" .$service->id;
}


public function disableCrystalballService(Request $request,$id){
$service = CrystalballService::find($id);
$service->status_id = "2";
$service->save();
return "success updating" .$service->id;
  }

  public function storeCrystalballService(Request $request){
  $err = "exist";
  $crystal = CrystalballService::where('service_name','=',$request['service_name'])->first();
  if($crystal === null){
  $crystal = new CrystalballService;
  $crystal->service_name = $request['service_name'];
  $crystal->save();

  $last_service_id = $crystal->id;
  $order_acc= $request['copier_id'];

  foreach($order_acc as $value)
  {
    $copier_acc = new ServiceAll;
    $copier_acc->copier_id = $value;
    $copier_acc->service_id = $last_service_id;
    $copier_acc->save();

      }
return Response::json(['services' => $copier_acc]);
  }
else{
return Response::json(['exists' => $err]);
  }
}

} //class closed
