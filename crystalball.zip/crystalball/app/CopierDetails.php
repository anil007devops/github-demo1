<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CopierDetails extends Model
{
  protected $fillable = [
      'copier_id','accessory_id', 'payment_id',
  ];
}
