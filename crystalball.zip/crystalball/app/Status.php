<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Status extends Model
{
  protected $fillable = [
      'category_id','copier_id','accessory_id','payment_option_id','status',
  ];
}

?>
