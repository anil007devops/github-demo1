<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ServiceAll extends Model
{
  protected $fillable = [
      'copier_id','service_id',
  ];
}
