<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CopierAccessory extends Model
{
  protected $fillable = [
      'copier_id','accessory_id',
  ];
}
