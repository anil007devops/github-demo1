<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CrystalballPolicy extends Model
{
  protected $fillable = [
      '	policy_description','status_id',
  ];
}
