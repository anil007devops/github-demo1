<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCopiersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('copiers', function (Blueprint $table) {
            $table->increments('id');
            $table->string('copier_model');
            $table->string('print_page_per_minute');
            $table->string('monthly_pages');
            $table->float('monthly_price');
            $table->float('price_color_page');
            $table->float('price_bw_page');
            $table->string('used_by');
            $table->string('plan');
          //  $table->string('image');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('copiers');
    }
}
