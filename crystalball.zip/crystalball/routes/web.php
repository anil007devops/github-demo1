<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('index');
});



// Route::get('/api/v1/employees/{id?}', 'Employees@index');
Route::post('signup', 'UserController@store');

Route::get('orderhistory/{id}','OrderHistoryController@getOrderHistory');

Route::post('userdetails', 'UserController@storeUser');
Route::get('summary','CopierController@getInfo');
Route::get('logout','AuthController@getLogout');
Route::post('auth','AuthController@postLogin');
Route::get('customers','UserController@getIndex');

Route::post('summary-details/{id}','SummaryController@getSummary');


Route::get('payment-options', 'PaymentController@getPayment');
Route::post('add-payments', 'PaymentController@storePaymentDetails');
Route::post('payments/{id}', 'PaymentController@editPayment');
Route::post('delete-payments/{id}', 'PaymentController@disablePayment');

//copiers
Route::get('copiers','CopierController@getIndex');   // get copiers and display
Route::post('add-copiers', 'CopierController@storeCopierDetails');  //add copiers to database
Route::post('copiers/{id}','CopierController@editCopiers');  //edit copier and update to database
Route::post('delete-copiers/{id}','CopierController@disableCopiers');
Route::get('pull-copier-details/{id}','CopierController@getAll');


//accessories
Route::get('accessories','AccessoryController@getAccessory');  //get accessories and dispaly on browser
Route::post('add-accessories', 'AccessoryController@storeAccessoryDetails'); //add accessories in database
Route::post('accessories/{id}','AccessoryController@editAccessory');  //edit accessory and update in database
Route::post('delete-accessories/{id}','AccessoryController@disableAccessory');
Route::post('get-copier-accessories/{id}','AccessoryController@getCopierAccessoryById');

//categories
Route::get('categories','CategoryController@getCategory');
Route::post('categories/{id}/{category_name}','CategoryController@editCategory');
Route::post('delete-categories/{id}','CategoryController@disableCategory');
Route::post('add-categories', 'CategoryController@storeCategoryDetails');

//crystallball copiers service Routes
Route::post('add-crystalballservice', 'CrystalballServiceController@storeCrystalballService');
Route::get('crystalballservice', 'CrystalballServiceController@getCrystalballService');
Route::post('crystalballservice/{id}', 'CrystalballServiceController@editCrystalballService');
Route::post('delete-crystalballservice/{id}','CrystalballServiceController@disableCrystalballService');
Route::get('getcrystalballservices/{copier_id}', 'CrystalballServiceController@getCrystalballServiceforsummary');

//crystalball policy Routes
Route::post('add-crystalballpolicy', 'CrystalballPolicyController@storePolicyDetails');
Route::get('crystalballpolicy', 'CrystalballPolicyController@getPolicy');
Route::post('crystalballpolicy/{id}', 'CrystalballPolicyController@editPolicy');
Route::post('delete-crystalballpolicy/{id}', 'CrystalballPolicyController@disablePolicy');

//Route::get('customers',[
//   'uses'=> 'UserController@getIndex',
//    'middleware'=>'roles',
//    'roles'=> ['Admin']
//]);







//Route::post('/api/v1/customers/login', 'AdminController@postLogin');
//Route::get('/admin/login','AdminController@getLogin')->name('admin.login2');

//
//
//Route::get('/login2',function(){
//   return view('login2');
//})->name('login2');  // it will redirect to login page
//
//Route::get('/admin',function(){
//   return view('admin.adminDashboard');
//})->name('adminDashboard'); // it will redirect to dashboard


//Route::post('/login','AdminController@postLogin')->name('admin.login2'); // this will be used when post action performed in form.
//Route::post('/admin','AdminController@getIndex')->name('adminDashboard');
//Route::post('/about')->name('about');
// Route::post('/api/v1/employees/{id}', 'Employees@update');
// Route::delete('/api/v1/employees/{id}', 'Employees@destroy');

?>
