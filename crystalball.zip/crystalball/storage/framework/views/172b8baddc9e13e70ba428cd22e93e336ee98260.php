<footer class="main-footer">
    <nav>
        <ul>

            <li><a href="<?php echo e(route('about')); ?>">About</a></li>
        </ul>

    </nav>
</footer>