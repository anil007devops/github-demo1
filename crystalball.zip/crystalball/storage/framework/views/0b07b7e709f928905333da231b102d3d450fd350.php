<h2>Thank You for creating Quotes Dear :  <?php echo e($name); ?></h2>
<p>
    Please register here: <a href="<?php echo e(route('mailcallback',['author_name'=> $name])); ?>">Link</a>
</p>