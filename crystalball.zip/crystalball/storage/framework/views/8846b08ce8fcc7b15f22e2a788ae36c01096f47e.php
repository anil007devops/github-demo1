<?php $__env->startSection('styles'); ?>

    <link rel="stylesheet" href="<?php echo e(URL::to('src/css/common.css')); ?>" type="text/css"/>
    <?php $__env->appendSection(); ?>

<?php if(Session::has('fail')): ?>
<section class="info-box fail">
    <?php echo e(Session::get('fail')); ?>

</section>
    <?php endif; ?>


<?php if(Session::has('success')): ?>
    <section class="info-box success">
        <?php echo e(Session::get('success')); ?>

    </section>
<?php endif; ?>

<?php if(count($errors)>0): ?>
   <section class="info-box fail">
       <ul>
           <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
               <li><?php echo e($error); ?></li>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
       </ul>
   </section>
    <?php endif; ?>
